package test1;
import java.util.Scanner;
public class ATMMachine1 {
	public static void main(String[] args){
		@SuppressWarnings("resource")
		Scanner input=new Scanner(System.in);
		Account1 []account=new Account1[100];
		for(int i=0;i<100;i++){
			try{
				account[i]=new  Account1(i, 1000.0);
			}
			catch(AccountException ex){
				System.out.println(ex);		
			}
		}
		int id;
		while(true){
			System.out.println("Please enter your ID.");
			while(true) {							
				try {
					id = input.nextInt();			
					break;								
				}
				catch(Exception e) {				
					System.out.println("You didn't enter an integer.Please type again.");
					input.next();						
				}
			}
			if(id>=0 && id<100){
				break;
			}
			else{
				System.out.println("The ID does not exist,please type again.");
			}
		}
		int choose=0;
		do{
			menu();
			
			while(true){
				System.out.println("Please select 1-4.");
				while(true){
					try{
						choose=input.nextInt();
						break;
					}
					catch(Exception e){
						System.out.println("You didn't enter an integer.Please type again.");
						input.next();		
					}
				}
				if(choose>=1 && choose<=4){
					break;
				}
				else{
					System.out.println("Input Error!");
				}
			}
		
		    double money;	
			if(choose==1){
				System.out.println(account[id].toString());
			}
			else if(choose == 2){
				System.out.println("How much do you need to take out?");
				while(true){
					try{
						money=input.nextDouble();
						break;
					}
					catch(Exception e){
						System.out.println("Input error.Please type again.");
						input.next();		
					}
				}
				if(money>account[id].getBalance()){
					System.out.println("You don't have that kind of money.");
				}
				else{
				account[id].withDraw(money);
				System.out.println("Successful withdrawal.");
				}
			}
			else if(choose == 3){
				System.out.println("How much do you need to deposit?");
				while(true){
					try{
						money=input.nextDouble();
						break;
					}
					catch(Exception e){
						System.out.println("Input error.Please type again.");
						input.next();		
					}
				}
				account[id].deposit(money);
				System.out.println("Successful deposit");
			}		
			else {				
				System.out.println("Welcome next time.");
				break;
			}		    		
		}while(choose!=4);
	}
	
	public static void menu(){
		System.out.println("1.check balance");
		System.out.println("2:withdraw");
		System.out.println("3:deposit");
		System.out.println("4:exit");
	}
	
}
