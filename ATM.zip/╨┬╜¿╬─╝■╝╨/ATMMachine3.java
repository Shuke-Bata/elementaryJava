package test1;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ATMMachine3 extends Application{
	static ArrayList<Account2> accountList=new ArrayList<Account2>();
	static Account2 account=new Account2();
	int index;
	boolean loIdFlag  = false;
	boolean loPasFlag = false;	
	boolean reIdFlag  = false;
	boolean rePasFlag = false;	
	boolean reBaFlag  = false;
	boolean reAnFlag  = false;
	boolean chPas1    = false;
	boolean chPas2    = false;
	static Stage myStage;
	static Button bt0=new Button("0");
	static Button bt1=new Button("1");
	static Button bt2=new Button("2");
	static Button bt3=new Button("3");
	static Button bt4=new Button("4");
	static Button bt5=new Button("5");
	static Button bt6=new Button("6");
	static Button bt7=new Button("7");
	static Button bt8=new Button("8");
	static Button bt9=new Button("9");
	static Button btBackSpace=new Button("��");
	static Button btEmpty=new Button("empty");
	
	public void start(Stage primaryStage){
		 myStage=primaryStage;
		 mainPane();
	}
	public void mainPane(){
		GridPane  mainPane=new GridPane();
		GridPane  pane1=new GridPane();
		GridPane  pane2=keyboard();
		TextField txId =new TextField();
		TextField txPas=new TextField();
		
		Button btRe=new Button("Regist");
		Button btLo=new Button("Login");
		btRe.setPrefWidth(105);
		btLo.setPrefWidth(105);
		Label label1=new Label("Id      :");
		Label label2=new Label("Password:");
		pane1.setPadding(new Insets(10,10,10,10));
		pane1.setHgap(20);
		pane1.setVgap(20);
		txId.setPrefWidth(60);
		txPas.setPrefWidth(60);
		pane1.addColumn(0, label1,label2,btRe);
		pane1.addColumn(1, txId,txPas,btLo);
	
		
		mainPane.add(pane1,0,0);
		mainPane.add(pane2,0,1);

		btLo.setOnAction(e->{
			int id=Integer.parseInt(txId.getText());
			String pas=txPas.getText();
			index=login(id, pas);
			Alert warningAlert=new Alert(AlertType.INFORMATION);
			warningAlert.setTitle("System Tips");
			if(index==-1){
				warningAlert.setHeaderText("The ID does not exist.");
				warningAlert.setContentText("Please type again.");
				warningAlert.showAndWait();
			}
			else if(index==-2){
				warningAlert.setHeaderText("Password Error.");
				warningAlert.setContentText("Please type again.");
				warningAlert.showAndWait();
			}
			else{
				loPane();
			}
		});
		btRe.setOnAction(e->{
			rePane();
		});
		txId.setOnMouseClicked(e->{
			loIdFlag=true;
			loPasFlag=false;
		});
	
		txPas.setOnMouseClicked(e->{
			loPasFlag=true;
			loIdFlag=false;
		});
		bt0.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"0");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"0");
			}
		});
		bt1.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"1");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"1");
			}
		});
		bt2.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"2");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"2");
			}
		});
		bt3.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"3");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"3");
			}
		});
		bt4.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"4");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"4");
			}
		});
		bt5.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"5");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"5");
			}
		});
		bt6.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"6");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"6");
			}
		});
		bt7.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"7");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"7");
			}
		});
		bt8.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"8");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"8");
			}
		});
		bt9.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				txId.setText(str+"9");
			}
			else if(loPasFlag){
				String str=txPas.getText();
				txPas.setText(str+"9");
			}
		});
		btBackSpace.setOnAction(e->{
			if(loIdFlag){
				String str=txId.getText();
				backSpace(txId,str);
			}
			else if(loPasFlag){
				String str=txPas.getText();
				backSpace(txPas,str);
			}
		});
		btEmpty.setOnAction(e->{
			if(loIdFlag){
				txId.setText("");
			}
			else if(loPasFlag){
				txPas.setText("");
			}
		});
		Scene scene=new Scene(mainPane);
		myStage.setScene(scene);
		myStage.show();
		
		
		

	}
	public void loPane(){
		GridPane pane=new GridPane();
		Button btBal=new Button("��ѯ���");
		Button btWit=new Button("ȡǮ");
		Button btDes=new Button("��Ǯ");
		Button btTrs=new Button("���׼�¼");
		Button btCha=new Button("�޸�����");
		Button btBac=new Button("����");
		btBal.setPrefWidth(70);
		btWit.setPrefWidth(70);
		btDes.setPrefWidth(70);
		btTrs.setPrefWidth(70);
		btCha.setPrefWidth(70);
		btBac.setPrefWidth(70);
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(20);
		pane.setVgap(20);	
		pane.add(btBal, 1, 1);
		pane.add(btWit, 1, 2);
		pane.add(btDes, 1, 3);
		pane.add(btTrs, 2, 1);
		pane.add(btCha, 2, 2);
		pane.add(btBac, 2, 3);
		btBac.setOnAction(e->{
			mainPane();
		});
		btBal.setOnAction(e->{
			balPane();
		});
		btWit.setOnAction(e->{
			witPane();
		});
		btDes.setOnAction(e->{
			desPane();
		});
		btCha.setOnAction(e->{
			chaPane();
		});
		btTrs.setOnAction(e->{
			trsPane();
		});
		Scene scene=new Scene(pane,240,260);
		myStage.setScene(scene);
		myStage.show();
	}
	public void witPane(){
		GridPane pane0=new GridPane();
		GridPane pane1=new GridPane();
		GridPane pane2=new GridPane();
		GridPane pane3=new GridPane();
		Label  label  =new Label("How much do you need to withdraw?");
		Button bt100  =new Button("     100   ");
		Button bt500  =new Button("       500  ");
		Button bt1000 =new Button("     1000  ");
		Button btOk   =new Button("     ok      ");
		Button btBack =new Button("    back    ");
		Button btnull =new Button();
		btnull.setVisible(false);
		TextField txMoney=new TextField();
		pane1.setAlignment(Pos.CENTER_LEFT);
		
		pane1.setPadding(new Insets(10,10,10,10));
		pane1.setVgap(20);	
		
		pane1.addColumn(1, label,txMoney);
		
		pane2.setPadding(new Insets(10,10,10,10));
		pane2.setHgap(10); 		
		pane2.setVgap(10);
		
		pane2.addRow(0, btBack,btnull,btOk);
		pane2.addRow(1, bt100,bt500,bt1000);
	
		pane3.add(keyboard(),0,3);

		pane0.addColumn(0, pane1,pane2,pane3);
		
		bt100.setOnAction(e->{
			txMoney.setText("100");
		});
		bt500.setOnAction(e->{
			txMoney.setText("500");
		});
		bt1000.setOnAction(e->{
			txMoney.setText("1000");
		});
		btBack.setOnAction(e->{
			loPane();
		});

		bt0.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"0");
		});
		bt1.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"1");
		});
		bt2.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"2");
		});
		bt3.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"3");
		});
		bt4.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"4");
		});
		bt5.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"5");
		});
		bt6.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"6");
		});
		bt7.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"7");
		});
		bt8.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"8");
		});
		bt9.setOnAction(e->{
			String str=txMoney.getText();
			txMoney.setText(str+"9");
		});
		btBackSpace.setOnAction(e->{
			String str=txMoney.getText();
			backSpace(txMoney,str);
		});
		btEmpty.setOnAction(e->{
			txMoney.setText("");
		});
		btOk.setOnAction(e->{
			double money=Double.parseDouble(txMoney.getText());
			Alert warningAlert=new Alert(AlertType.INFORMATION);
			warningAlert.setTitle("System Tips");
			if(money%100!=0){
				
				warningAlert.setHeaderText("It must be divisible by a hundred.");
				warningAlert.setContentText("Please type again.");
				warningAlert.showAndWait();
			}
			else if(money>accountList.get(index).getBalance()){
				warningAlert.setHeaderText("Insufficient balance.");
				warningAlert.setContentText("Please type again.");
				warningAlert.showAndWait();
			}
			else{
				accountList.get(index).withDraw(money);
				try {
					writeAccountList(accountList);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				witOkPane();
			}
		});
		Scene scene=new Scene(pane0,260,300);
		myStage.setScene(scene);
		myStage.show();
		
		
	}
	public void witOkPane() {
		GridPane pane=new GridPane();
		Label label=new Label("Balance become:"+accountList.get(index).getBalance());
		Button btOk=new Button("      ok       ");
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(20);
		pane.setVgap(20);
		pane.add(label, 1, 1);
		pane.add(btOk, 1, 2);
		Scene scene=new Scene(pane);
		btOk.setOnAction(e->{
			loPane();
		});
		myStage.setScene(scene);
		myStage.show();
		
	}
	public void balPane(){
		GridPane pane=new GridPane();
		Label label=new Label("Balance is:"+accountList.get(index).getBalance());
		Button btOk=new Button("      ok       ");
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(20);
		pane.setVgap(20);
		pane.add(label, 1, 1);
		pane.add(btOk, 1, 2);
		Scene scene=new Scene(pane);
		btOk.setOnAction(e->{
			loPane();
		});
		myStage.setScene(scene);
		myStage.show();

	}
	public void desPane(){
		GridPane pane=new GridPane();
		Label label=new Label("Please put the money in the deposit window.");
		Button btOk =new Button("I put it ok.");
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(20);
		pane.setVgap(20);
		pane.add(label, 1, 1);
		pane.add(btOk, 1, 2);
		Scene scene=new Scene(pane);
		btOk.setOnAction(e->{
			desOkPane();
		});
		myStage.setScene(scene);
		myStage.show();
		
	}
	public void desOkPane() {
		GridPane pane=new GridPane();
		Label lable1=new Label("System detected $300.");
		accountList.get(index).deposit(300);
		try {
			writeAccountList(accountList);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Label lable2=new Label("Balance become:"+accountList.get(index).getBalance());
		Button btOk=new Button("      ok       ");
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(20);
		pane.setVgap(20);
		pane.add(lable1, 1, 1);
		pane.add(lable2, 1, 2);
		pane.add(btOk, 1, 3);
		Scene scene=new Scene(pane);
		btOk.setOnAction(e->{
			loPane();
		});
		myStage.setScene(scene);
		myStage.show();
		
	}
	public void chaPane(){
		GridPane pane0=new GridPane();
		GridPane pane1=new GridPane();
		GridPane pane3=keyboard();
		GridPane pane2=new GridPane();
		Label label=new Label("Please enter a new password twice.");
		TextField txPas1=new TextField();
		TextField txPas2=new TextField();
		Button btOk=new Button("ok");
		Button btBack=new Button("back");
		pane1.setAlignment(Pos.CENTER_LEFT);
		pane1.setPadding(new Insets(10,10,10,10));
		pane1.setHgap(20);
		pane1.setVgap(20);
		pane1.addColumn(0,label,txPas1,txPas2);
		pane2.setPadding(new Insets(10,10,10,10));
		pane2.setHgap(90);
		pane2.setVgap(20);
		btBack.setPrefWidth(70);
		btOk.setPrefWidth(70);
		pane2.addRow(0, btBack,btOk);
		pane0.addColumn(0, pane1,pane2,pane3);
		Scene scene=new Scene(pane0);
		btBack.setOnAction(e->{
			loPane();
		});
		btOk.setOnAction(e->{
			String str1=txPas1.getText();
			String str2=txPas2.getText();
			Alert warningAlert=new Alert(AlertType.INFORMATION);
			warningAlert.setTitle("System Tips");
			if(str1.length()<6 || str1.length()>10){
				warningAlert.setHeaderText("The password length must be 6 to 10.");
				warningAlert.setContentText("Please type again.");
				warningAlert.showAndWait();
			}
			else if(!str1.equals(str2)){
				warningAlert.setHeaderText("Two different inputs.");
				warningAlert.setContentText("Please type again.");
				warningAlert.showAndWait();
			}
			else{
				accountList.get(index).setPassword(str1);
				try {
					writeAccountList(accountList);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				chaOkPane();
			}
		});
		txPas1.setOnMouseClicked(e->{
			chPas1=true;
			chPas2=false;
		});
	
		txPas2.setOnMouseClicked(e->{
			chPas2=true;
			chPas1=false;
		});
		bt0.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas2.setText(str+"0");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"0");
			}
		});
		bt1.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"1");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"1");
			}
		});
		bt2.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"2");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"2");
			}
		});
		bt3.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"3");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"3");
			}
		});
		bt4.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"4");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"4");
			}
		});
		bt5.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"5");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"5");
			}
		});
		bt6.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"6");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"6");
			}
		});
		bt7.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"7");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"7");
			}
		});
		bt8.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"8");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"8");
			}
		});
		bt9.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				txPas1.setText(str+"9");
			}
			else if(chPas2){
				String str=txPas2.getText();
				txPas2.setText(str+"9");
			}
		});
		btBackSpace.setOnAction(e->{
			if(chPas1){
				String str=txPas1.getText();
				backSpace(txPas1,str);
			}
			else if(chPas2){
				String str=txPas2.getText();
				backSpace(txPas2,str);
			}
		});
		btEmpty.setOnAction(e->{
			if(chPas1){
				txPas1.setText("");
			}
			else if(chPas2){
				txPas2.setText("");
			}
		});
		myStage.setScene(scene);
		myStage.show();
		
	}
	public void chaOkPane() {
		GridPane pane=new GridPane();
		Label label=new Label("Modified successfully!\nPlease login again.");
		Button btOk=new Button("      ok       ");
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(20);
		pane.setVgap(20);
		pane.add(label, 1, 1);
		pane.add(btOk, 1, 2);
		Scene scene=new Scene(pane);
		btOk.setOnAction(e->{
			mainPane();
		});
		myStage.setScene(scene);
		myStage.show();
		
		
	}
	@SuppressWarnings("deprecation")
	public void trsPane(){
		GridPane pane=new GridPane();
		ArrayList<Transation> record=new ArrayList<Transation>();
		Label[] label=new Label[accountList.get(index).getRecord().size()];
		Button btOk=new Button("      ok       ");
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(20);
		pane.setVgap(20);
		record=accountList.get(index).getRecord();
		if(label.length!=0){
			for(int i=0;i<label.length;i++){
				label[i]=new Label("At:"+record.get(i).getDate().toLocaleString()+"\n"+record.get(i).getDescription());
				pane.add(label[i], 1, i);		
			}
			pane.add(btOk, 1, label.length);
		}
		else{
			Label label2=new Label("Transaction log is empty.");		
			pane.add(label2, 1, 1);		
			pane.add(btOk  , 1, 2);
		}
		Scene scene=new Scene(pane);
		btOk.setOnAction(e->{
			loPane();
		});
		myStage.setScene(scene);
		myStage.show();
	}
	public void reOkPane(){
		GridPane pane=new GridPane();
		Label label=new Label("Successful registration!");
		Button btOk=new Button("      ok       ");
		pane.setAlignment(Pos.CENTER_LEFT);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(20);
		pane.setVgap(20);	
		pane.add(label, 1, 1);
		pane.add(btOk, 1, 2);
		Scene scene=new Scene(pane);
		btOk.setOnAction(e->{
			mainPane();
		});
		myStage.setScene(scene);
		myStage.show();
	}
	public void rePane(){
		GridPane  pane0  = new GridPane();
		GridPane  pane1  = new GridPane();
		GridPane  pane2  = new GridPane();
		GridPane  pane3  = keyboard();
		TextField txId   = new TextField();
		TextField txPas  = new TextField();
		TextField txBal  = new TextField();
		TextField txAnu  = new TextField();
		Label     lb1    = new Label ("Id:");
		Label     lb2    = new Label ("Password:");
		Label     lb3    = new Label ("Balance:");
		Label     lb4    = new Label ("Anu:");
		Button btOk=new Button("ok");
		Button btBack=new Button("back");
		Button btpoint = new Button(".");
		pane1.setAlignment(Pos.CENTER_LEFT);
		pane1.setPadding(new Insets(10,10,10,10));
		pane1.setHgap(2);
		pane1.setVgap(5);	
		pane1.addColumn(0, lb1,lb2,lb3,lb4);
		pane1.addColumn(1,txId,txPas,txBal,txAnu);
		pane2.addRow(0, btBack,btpoint,btOk);
		btBack.setPrefWidth(70);
		btOk.setPrefWidth(70);
		btpoint.setPrefWidth(70);
		pane2.setPadding(new Insets(10,10,10,10));
		pane2.setHgap(10);
		pane0.add(pane1, 0, 1);
		pane0.add(pane2, 0, 2);
		pane0.add(pane3, 0, 3);
		Scene scene=new Scene(pane0);
		btBack.setOnAction(e->{
			txId.setText("");
			txPas.setText("");
			mainPane();
		});
		txId.setOnMouseClicked(e->{
			changeValue("id");
		});
		txPas.setOnMouseClicked(e->{
			changeValue("password");
		});
		txBal.setOnMouseClicked(e->{
			changeValue("balance");
		});
		txAnu.setOnMouseClicked(e->{
			changeValue("anu");
		});
		
		bt0.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"0");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"0");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"0");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"0");
			}
		});
		bt1.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"1");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"1");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"1");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"1");
			}
		});
		bt2.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"2");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"2");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"2");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"2");
			}
		});
		bt3.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"3");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"3");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"3");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"3");
			}
		});
		bt4.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"4");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"4");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"4");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"4");
			}
		});
		bt5.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"5");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"5");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"5");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"5");
			}
		});
		bt6.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"6");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"6");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"6");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"6");
			}
		});
		bt7.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"7");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"7");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"7");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"7");
			}
		});
		bt8.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"8");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"8");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"8");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"8");
			}
		});
		bt9.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				txId.setText(str+"9");
			}
			else if(rePasFlag){
				String str=txPas.getText();
				txPas.setText(str+"9");
			}
			else if(reBaFlag){
				String str=txBal.getText();
				txBal.setText(str+"9");
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				txAnu.setText(str+"9");
			}
		});
		btBackSpace.setOnAction(e->{
			if(reIdFlag){
				String str=txId.getText();
				backSpace(txId,str);
			}
			else if(rePasFlag){
				String str=txPas.getText();
				backSpace(txPas,str);
			}
			else if(reBaFlag){
				String str=txBal.getText();
				backSpace(txBal,str);
			}
			else if(reAnFlag){
				String str=txAnu.getText();
				backSpace(txAnu,str);
			}
		});
		btEmpty.setOnAction(e->{
			if(reIdFlag)      {	txId .setText("");	}
			else if(rePasFlag){	txPas.setText("");  }			
			else if(reBaFlag ){	txBal.setText("");	}
			else if(reAnFlag ){	txAnu.setText("");	}
		});
		btOk.setOnAction(e->{
			Alert warningAlert=new Alert(AlertType.INFORMATION);
			warningAlert.setTitle("System Tips");
			int id=Integer.parseInt(txId.getText());
			String pas=txPas.getText();
			double balance=Double.parseDouble(txBal.getText());
			double anu=Double.parseDouble(txAnu.getText());
			if(login(id, pas)!=-1){
				warningAlert.setHeaderText ("The ID already exists.");
				warningAlert.setContentText("Please type again.");
				warningAlert.showAndWait();
			}
			else if(pas.length()<6  ||  pas.length()>10){
				warningAlert.setHeaderText ("The password must be 6-10 in length.");
				warningAlert.setContentText("Please type again.");
				warningAlert.showAndWait();
			}
			else{
				try {
					accountList.add(new Account2(id,balance,pas,anu));
					writeAccountList(accountList);
				} catch (AccountException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				reOkPane();
			}
		});
		myStage.setScene(scene);
		myStage.show();
		
	}
	public  static GridPane keyboard(){
		GridPane pane=new GridPane();
		pane.addRow(0, bt1,bt4,bt7);
		pane.addRow(1, bt2,bt5,bt8);
		pane.addRow(2, bt3,bt6,bt9);
		pane.addRow(3, btBackSpace,bt0,btEmpty);
		pane.setPadding(new Insets(10,10,10,10));
		pane.setHgap(10); 		pane.setVgap(10);
		return pane;
		
	}
	private static ArrayList<Account2> getAccountList() throws IOException    {
		ArrayList<Account2>accountList=new ArrayList<Account2>();
		Account2 temAccount=new Account2();
        File file =new File("account.dat");
        FileInputStream in;
    	in = new FileInputStream(file);        
        ObjectInputStream objIn=new ObjectInputStream(in);
        try {
            while(true){
	            temAccount=(Account2) objIn.readObject();
	            accountList.add(temAccount);
            }
        } catch (IOException e) {
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        in.close();
        objIn.close();
        return accountList;
	}
	public  static void writeAccountList(ArrayList<Account2> accountList) throws IOException{
		File file = new File("account.dat");
		OutputStream os = new FileOutputStream(file);  
		BufferedOutputStream bos = new BufferedOutputStream(os);
		MyObjectOutputStream oos = MyObjectOutputStream.newInstance(file, bos);  
		for(int i=0;i<accountList.size();i++){
			oos.writeObject(accountList.get(i));
		}
		oos.close();
	}
	public  int login(int id,String pas){
		for(int i=0;i<accountList.size();i++){
			if(accountList.get(i).getId()==id){
				if(pas.equals(accountList.get(i).getPassword())){
					return i;
				}
				else{
					return -2;
				}
			}
		}
		return -1;
	}
	public  void  backSpace(TextField tx,String str1){
		tx.setText("");
		char []str2=new char[str1.length()-1];
		String str=new String();
		for(int i=0;i<str2.length;i++){
			str2[i]=str1.charAt(i);
			str=tx.getText();
			tx.setText(str+str2[i]);
		}
	}
	public  void changeValue(String str){
		if(str.equals("id")){
			reIdFlag=true ;rePasFlag=false;reBaFlag=false;reAnFlag=false;
		}
		else if(str.equals("password")){
			reIdFlag=false;rePasFlag=true ;reBaFlag=false;reAnFlag=false;
		}
		else if(str.equals("balance")){
			reIdFlag=false;rePasFlag=false;reBaFlag=true ;reAnFlag=false;
		}
		else if(str.equals("anu")){
			reIdFlag=false;rePasFlag=false;reBaFlag=false;reAnFlag=true;
		}
	}
	public  static void main(String[]args) throws IOException{
		accountList=getAccountList();
		bt0.setPrefWidth(70);
		bt1.setPrefWidth(70);
		bt2.setPrefWidth(70);
		bt3.setPrefWidth(70);
		bt4.setPrefWidth(70);
		bt5.setPrefWidth(70);
		bt6.setPrefWidth(70);
		bt7.setPrefWidth(70);
		bt8.setPrefWidth(70);
		bt9.setPrefWidth(70);
		btBackSpace.setPrefWidth(70);
		btEmpty.setPrefWidth(70);
		launch(args);
	}	
}
