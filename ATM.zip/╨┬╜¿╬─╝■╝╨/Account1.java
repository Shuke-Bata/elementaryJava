package test1;

import java.util.Date;

public class Account1 implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id = 0;
	private double balance = 0.0;
	private double annualInterestRate = 0.0;
	private transient Date dateCreated=new Date();
	public  Account1() {
	
	}

	public  Account1(int id, double balance) throws AccountException{
		String str=String.format("%.2f",balance);
		balance=Double.parseDouble(str);
		this.setId(id);
		this.setBalance(balance);	
	}
	
	public double getMonthlyInterestRate() {
		return this.annualInterestRate/1200;
	}
	
	public void withDraw(double money) {
		String str=String.format("%.2f",money);
		money=Double.parseDouble(str);
		this.balance-=money;	

	}
	
	public void deposit(double money) {
		String str=String.format("%.2f",money);
		money=Double.parseDouble(str);
		this.balance+=money;	
	}

	public int getId() {
		return id;
	}

	public void setId(int id) throws AccountException{
		if(id>=0){
			this.id=id;
		}
		else{
			throw new AccountException(id);
		}
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) throws AccountException{
		if(balance>=0){
			this.balance=balance;
		}
		else{
			throw new AccountException(balance);
		}
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(double annualInterestRate) {
		String str=String.format("%.2f",annualInterestRate);
		annualInterestRate=Double.parseDouble(str);
		this.annualInterestRate = annualInterestRate;
	}

	public Date getDateCreated() {
		return dateCreated;
	}
	
	@SuppressWarnings("deprecation")
	public String toString(){
		return  "id         :  " +id+"\nbalance    :  "+balance+"\ndateCreated:  "+dateCreated.toLocaleString();
		
	}
}

class AccountException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id = 0;
	private double balance = 0.0;
	public AccountException(int id){
		super("Invalid id :"+id);
		this.id=id;
	}
	public AccountException(double balance){
		super("Invalid balance :"+balance);
		this.balance=balance;
	}
	public int getId() {
		return id;
	}
	public double getBalance() {
		return balance;
	}
	
}
