package test1;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ATMMachine2 {
	
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException, AccountException  {
		@SuppressWarnings("resource")
		Scanner input=new Scanner(System.in);
		int choose1;
		int choose2;
		while(true){//menu1
			menu1();
			while(true){
				try{				
					choose1=input.nextInt();	
					break;
				}
				catch(InputMismatchException e){
					input.nextLine();
					System.out.println("Input eorro,please enter again.");
				}
		  	}
			if(choose1==1){
				operation1();
				break;
			}
			else if(choose1==2){
				int index=regeist();
				if(index>=0){
					while(true){
						menu2();
						while(true){
							try{				
								choose2=input.nextInt();
								break;
							}
							catch(InputMismatchException e){
								input.nextLine();
								System.out.println("Input eorro,please enter again.");
							}
					  	}
						if(choose2>=1 && choose2 <=5){
							operation2(choose2,index);
						}
						else if(choose2==6){
							break;
						}
						else{
							System.out.println("Input eorro,please enter again.");
						}
					}
				}
				else{
					break;
				}
				
			}
			else if(choose1==3){
				break;
			}
			else{
				System.out.println("Input eorro.");
			}

		}
		System.out.println("Weclome next time");
	}
	
	public static void menu1(){
		System.out.println("1:Create a account");
		System.out.println("2:Login");
		System.out.println("3:exit");
	}
	
	public static void menu2(){
		System.out.println("1:check balance");
		System.out.println("2:withdraw");
		System.out.println("3:deposit");
		System.out.println("4:details of the transaction");
		System.out.println("5:change password");
		System.out.println("6:back");
	}
	
	public static void operation1() throws FileNotFoundException, IOException, ClassNotFoundException, AccountException{
		Account2 account = CreatNewAccount();
		WriteNewAccount(account); 
	}
	
	@SuppressWarnings("deprecation")
	public static void operation2(int choose2,int index) throws IOException{
		@SuppressWarnings("resource")
		Scanner input=new Scanner(System.in);
		ArrayList<Account2> accountList = getAccountList();

			if(index>=0){
				
				if(choose2==1){
					System.out.println("\nBalance:"+accountList.get(index).getBalance());
				}
				else if(choose2==2){
					while(true){
						double money;
						while(true){
							System.out.println("How much do you want to withdraw?");
							try{
								money=input.nextDouble();							
								break;
							}
							catch(InputMismatchException e){
								input.nextLine();
								System.out.println("Input eorro,please enter again.");
							}
						}
						if(accountList.get(index).getBalance()-money>=0){
							accountList.get(index).withDraw(money);
							break;
						}
						else{
							System.out.println("Insufficient balance.");
						}
					}
				}
				else if(choose2==3){
					double money;
					while(true){
						System.out.println("How much do you want to deposit?");
						try{
							money=input.nextDouble();							
							break;
						}
						catch(InputMismatchException e){
							input.nextLine();
							System.out.println("Input eorro,please enter again.");
						}
					}
					accountList.get(index).deposit(money);
				}
				else if(choose2==4){
					Transation record=new Transation();
					for(int i=0;i<accountList.get(index).getRecord().size();i++){
						record=accountList.get(index).getRecord().get(i);
						System.out.println("At:"+record.getDate().toLocaleString()+record.getDescription());
					}
				}			
				else if(choose2==5){
					System.out.println("Please enter an old password.");
					String OldPassword=input.next();
					System.out.println("Enter new password.");
					String NewPassword1=input.next();
					System.out.println("Type again.");
					String NewPassword2=input.next();
					accountList.get(index).changePassword(OldPassword,NewPassword1,NewPassword2);
				}
	
			}

		writeAccountList(accountList);
	}
	
	private static ArrayList<Account2> getAccountList() throws IOException   {
		ArrayList<Account2>accountList=new ArrayList<Account2>();
		Account2 temAccount=new Account2();
        File file =new File("account.dat");
        FileInputStream in;
    	in = new FileInputStream(file);        
        @SuppressWarnings("resource")
		ObjectInputStream objIn=new ObjectInputStream(in);
        try {
            while(true){
	            temAccount=(Account2) objIn.readObject();
	            accountList.add(temAccount);
            }
        } catch (IOException e) {
            
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return accountList;
	}

	public static Account2   CreatNewAccount () throws FileNotFoundException, IOException, ClassNotFoundException, AccountException 
			{
		Account2 account=new Account2();
		@SuppressWarnings("resource")
		Scanner input=new Scanner(System.in);
		String name;
		while(true){
			System.out.println("Enter your name.");
			try{
			    name=input.next();
				break;
			}
			catch(InputMismatchException e){
				input.nextLine();
				System.out.println("Input eorro,please enter again.");
			}
		}
		double balance;
		while(true){
			System.out.println("Enter your balance.");
			try{
				balance=input.nextDouble();
				break;
			}
			catch(InputMismatchException e){
				input.nextLine();
				System.out.println("Input eorro,please enter again.");
			}
		}
		 account=new Account2(balance);
		String password;
		while(true){
			while(true){
				System.out.println("Enter your password??");
				try{
					password = input.next();		
					account.setPassword(password);
					break;
				}
				catch(InputMismatchException e){
					input.nextLine();
					System.out.println("Input eorro,please enter again.");
				}
			}

			if(password.equals(account.getPassword())){
				break;
			}
		}
		
		double annualInterestRate;
		while(true){
			System.out.println("Enter your annualInterestRate.");
			try{
				annualInterestRate=input.nextDouble();
				break;
			}
			catch(InputMismatchException e){
				input.nextLine();
				System.out.println("Input eorro,please enter again.");
			}
		}
		account.setAnnualInterestRate(annualInterestRate);
		account.setName(name);
		System.out.println("\nCreat sussfully,info:  \n"+account.toString());
		return account;
		
	}
	
	public static void storeNewAccountToList(Account2 newAccount,ArrayList<Account2> accountList){
		accountList.add(newAccount);
	}
	
	public static void       WriteNewAccount   (Account2 account) 
			throws FileNotFoundException, IOException{
		File file = new File("account.dat");
		OutputStream os = new FileOutputStream(file,true); 
		BufferedOutputStream bos = new BufferedOutputStream(os);
		MyObjectOutputStream oos = MyObjectOutputStream.newInstance(file, bos);  
		oos.writeObject(account);
		oos.close();
	}
	

	
	public static int  FindAccountFromList(int id,ArrayList<Account2>accountList){
		for(int i=0;i<accountList.size();i++){
			if(id==accountList.get(i).getId()){
				return i;
			}
		}
		return -1;
		
	}
	
	public static void writeAccountList(ArrayList<Account2> accountList) throws IOException{
		File file = new File("account.dat");
		OutputStream os = new FileOutputStream(file);  
		BufferedOutputStream bos = new BufferedOutputStream(os);
		MyObjectOutputStream oos = MyObjectOutputStream.newInstance(file, bos);  
		for(int i=0;i<accountList.size();i++){
			oos.writeObject(accountList.get(i));
		}
		oos.close();
	}
	
	public static int regeist() throws IOException{
		@SuppressWarnings("resource")
		Scanner input=new Scanner(System.in);
		ArrayList<Account2>accountList=getAccountList();
		int id;
		while(true){
			System.out.println("Enter your id.");	
			try{
				id=input.nextInt();
				break;
			}
			catch(InputMismatchException e){
				input.nextLine();
				System.out.println("Input eorro,please enter again.");
			}
		}
		String password;
		while(true){
			System.out.println("Enter your password.");
			try{
				password=input.next();
				break;
			}
			catch(InputMismatchException e){
				input.nextLine();
				System.out.println("Input eorro,please enter again.");
			}
		}
		int idIndex=FindAccountFromList(id,accountList);
		if(idIndex>=0){
			if(password.equals(   accountList.get(idIndex).getPassword()  )){
				return idIndex;
			}
			else{
				System.out.println("Password eorro!");
				return -1;
			}
		}
		else{
			System.out.println("Id is not exit.");
			return -1;
		}
	}
	
}

class MyObjectOutputStream extends ObjectOutputStream {
	private static File f;
	
	public static MyObjectOutputStream newInstance(File file, OutputStream out) throws IOException {
		f = file;
		return new MyObjectOutputStream(out, f);
	}
	
	protected void writeStreamHeader() throws IOException {
		if (!f.exists() || (f.exists() && f.length() == 0)) {
			super.writeStreamHeader();
		} else {
			super.reset();
		}
	}
	
	public MyObjectOutputStream(OutputStream out, File f) throws IOException {
		super(out);
	}

}

