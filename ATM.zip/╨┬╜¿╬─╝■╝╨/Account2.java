package test1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;
import test1.Transation;

public class Account2 extends Account1 implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String password;
	private String name;
	private  java.util.ArrayList<Transation> record = new java.util.ArrayList<Transation>();
	public Account2(){
	}
	public Account2(double balance) throws AccountException, FileNotFoundException {
		String str=String.format("%.2f",balance);
		balance=Double.parseDouble(str);
		 record = new java.util.ArrayList<Transation>();
		Random random=new Random();
		this.setBalance(balance);
		int newId;
		do{
			newId=random.nextInt(99)+1;
		}while(IdRepeat(newId));
		writeId(newId);
		this.setId(newId);	
	}
	public Account2(int id,double balance,String password,double anu) throws AccountException{
		this.setId(id);
		this.setBalance(balance);
		this.setPassword(password);
		this.setAnnualInterestRate(anu);
	}
	public void withDraw(double money) {
		String str=String.format("%.2f",money);
		money=Double.parseDouble(str);
		if(money%100==0){
			try {
				this.setBalance(this.getBalance()-money);
			} 
			catch (AccountException e) {
				System.out.println(e);
			}
  		   Transation transation=new Transation('W',money, this.getBalance(),"    withDraw: "+money+"   remain: "+this.getBalance());
	        record.add(transation);
	  //      System.out.println("After the withdrawal, the balance is:"+this.getBalance());
		}
		else{
		//	System.out.println("You can only withdraw 100 times as much money.");
		}
	}
	
	public void deposit(double money) {
		String str=String.format("%.2f",money);
		money=Double.parseDouble(str);
			try {
				this.setBalance(this.getBalance()+money);
			} 
			catch (AccountException e) {
				System.out.println(e);
			}
			Transation transation=new Transation('D',money, this.getBalance(),"      deposit: "+money+"   remain: "+this.getBalance());
	        record.add(transation);
//	        System.out.println("After the deposit, the balance is:"+this.getBalance());
	}
	
	public void changePassword(String OldPassword,String NewPassword1,String NewPassword2) {
		
		if(OldPassword.equals(this.password)){
			if(NewPassword1.equals(NewPassword2)){
				this.setPassword(NewPassword2);
				System.out.println("Change sussfully!");
			}
			else{
				System.out.println("NewPassword1!=NewPassword2");
			}
		}
		else{
			System.out.println("Old Password Error");
		}
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		if(password.length()>=6 && password.length()<=10 && IsDigitOrLetter(password)){
			this.password = password;
		}
		else{
			System.out.println("The password must be 6-10 and consist of numbers and letters.");
		}

	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public static boolean IsDigitOrLetter(String str){
		boolean flag;
		for(int i=0;i<str.length();i++){
			if(!Character.isLetterOrDigit(str.charAt(i))){
				flag=false;
				break;
			}
		}
		flag=true;
		return flag;
	}
	
	public String toString(){
		return super.toString()+"\name        :  "+this.name;
	}
	public java.util.ArrayList<Transation> getRecord() {
		return record;
	}
	
	public static boolean IdRepeat(int newId) throws FileNotFoundException {
		File file=new File("id.txt");
		@SuppressWarnings("resource")
		Scanner input = new Scanner(file);
		int []idList=new int[100];
		int i=0;
		while(input.hasNext()){
			idList[i]=input.nextInt();
			i++;
		}
		for(int j=0;idList[j]!=0;j++){
			if(newId==idList[j]){
				return true;
			}
		}		

		return false;
	}
	
	public static void writeId(int id){
		File f=new File("id.txt");
		FileWriter fw = null;
		try {
			fw = new FileWriter(f, true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		PrintWriter pw = new PrintWriter(fw);
		pw.println(id);
		pw.flush();
	}
	
}

