package curriculumdesign1;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.regex.Pattern;



public class ATMMachine2 {

	 
	private static ArrayList<Account2> accountList=new ArrayList<Account2>();

	static Pattern pattern = Pattern.compile("^[0-9]{6}");//正则表达式进行判断输入的字符
	
	public static void main(String[] args) throws ClassNotFoundException, FileNotFoundException, IOException {
		menu(0);
	}

	private static java.util.Scanner input = new java.util.Scanner(System.in);
	static int id;
	//主菜单
	public static void menu(int idNum) throws ClassNotFoundException, FileNotFoundException, IOException {
		int choice = 0;

		while (true) {
			System.out.println("Main menu");
			System.out.println("0:create a account");
			System.out.println("1: check balance ");
			System.out.println("2: withdraw ");
			System.out.println("3: deposit ");
			System.out.println("4:details of the transaction");
			System.out.println("5:change password");
			System.out.println("6: exit ");
			System.out.print("Enter a choice: ");
			choice = input.nextInt();
			if (choice < 0 || choice > 6) {
				System.out.println("Wrong choice, try again: ");
			} else {
				break;
			}
		}
		switch (choice) {
		case 0:
			accounts();
			break;
		case 1:
			balance(idNum);
			break;
		case 2:
			withdraw(idNum);
			break;
		case 3:
			deposit(idNum);
			break;
		case 4:
			transaction(idNum);
			break;
		case 5:
			changePassword(idNum);
			break;
		case 6:
			exit();
			break;
		}
	}

	// 随机生成id
	public static int randomId() {
		int id;
		ArrayList<Integer> list = new ArrayList<>();
		id = (int) (Math.random() * 100);
		for (int j = 0; j < list.size(); j++) {
			list.add(id);
		}
		// 对比存入数组中的数值是否与生成的ID相同，如果相同，重新生成，如果不同则设置id
		for (int i = 0; i < list.size(); i++) {
			if (list.equals(id)) {
				id = (int) (Math.random() * 100);
				continue;
			} 
		}
		return id;
	}

	// 创建账户
	public static void accounts() throws ClassNotFoundException, FileNotFoundException, IOException {
		Account2 account2 = new Account2();
		account2.setId(randomId());
		boolean judge=false;
		System.out.println("欢迎创建新账户");
			System.out.println("请输入账号：");
			input.nextLine();
			String accountName = input.nextLine();
			account2.setName(accountName);
		while (true) {
			System.out.println("请输入密码：");
			String accountPassword = input.nextLine();
			if (accountPassword.length() >= 6 && accountPassword.length() < 10&&pattern.matcher(accountPassword).matches()) {
				account2.setPassword(accountPassword);
				break;
			} else {
				System.out.println("密码长度不能小于6或者大于10且为纯数字，请重新输入！");
				continue;
			}
		}
		while(true){
			try{
			System.out.println("请输入初始金钱：");
			double accountBalance = input.nextDouble();
			account2.setBalance(accountBalance);
			System.out.println("请输入年利率：");
			double accountAnnualInterestRate = input.nextDouble();
			account2.setAnnualInterestRate(accountAnnualInterestRate);
			judge=true;
			}catch (Exception e) {
				System.out.println("输入错误，请重新输入！");
				input.nextLine();
				continue;
			}
			if(judge)
				break;
		}
		//添加对象进入ArrayList
		accountList.add(account2);
		writeToFile(accountList);
//		try {/**之前用于存入文件*/
//			ObjectOutputStream os=new ObjectOutputStream(new FileOutputStream("D:/account.dat",false));
//			os.writeObject(accountList);
//			os.close();
//		} catch (Exception e) {
//			
//		}
		//用于测试的输出
//		try {
//			ObjectInputStream is=new ObjectInputStream(new FileInputStream("D:/account.dat"));
//			for(int i=0;i<accountList.size();i++){
//				System.out.println(accountList.get(i).getName());
//				System.out.println(accountList.get(i).getPassword());
//				System.out.println(accountList.get(i).getBalance());
//			}
//			
//		} catch (Exception e) {
//		}
		menu(account2.getId());
	}
	//查询余额
	public static void balance(int id) throws ClassNotFoundException, FileNotFoundException, IOException {
		for(int i=0;i<accountList.size();i++){
			if(accountList.get(i).getId()==id){
				System.out.print("The balance is " + accountList.get(i).getBalance());
				System.out.println();
				break;
			}
		}
		menu(id);
	}
	//取钱板块
	public static void withdraw(int id) throws ClassNotFoundException, FileNotFoundException, IOException {
		System.out.print("Enter an amount to withdraw: ");
		int amount = input.nextInt();
		int i=0;
		for(i=0;i<accountList.size()-1;i++){
			if(accountList.get(i).getId()==id)
				break;
		}
		if (amount <= accountList.get(i).getBalance() && amount % 100 == 0) {
			input.nextLine();
			System.out.print("Add description: ");
			String description = input.nextLine();
			accountList.get(i).withDraw(amount,  description);
			writeToFile(accountList);
		} else {
			System.out.print("The amount is too large or not an integer multiple of 100 , ignored");
		}
		menu(id);
	}
	//存钱板块
	public static void deposit(int id) throws ClassNotFoundException, FileNotFoundException, IOException {
		System.out.print("Enter an amount to deposit: ");
		int amount = input.nextInt();
		int i=0;
		for(i=0;i<accountList.size();i++){
			if(accountList.get(i).getId()==id)
				break;
		}
		if (amount >= 0 && amount % 100 == 0) {
			input.nextLine();
			System.out.print("Add description: ");
			String description = input.nextLine();
			accountList.get(i).deposit(amount, description);
			writeToFile(accountList);
		} else {
			System.out.print("The amount is negative or not an integer multiple of 100, ignored");
		}
		menu(id);
	}

	// 存盘函数
		public static void writeToFile(ArrayList<Account2> accountList) throws FileNotFoundException, IOException {
			ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("D:/account.dat", false));
			os.writeObject(accountList);
			os.close();
		}
	
	
	// 获取交易记录
	public static void transaction(int id) throws ClassNotFoundException, FileNotFoundException, IOException {
		int i=0;
		for(i=0;i<accountList.size();i++){
			if(accountList.get(i).getId()==id){
				for(int j=0;j<accountList.get(i).transactions.size();j++){
				System.out.println("The Date is "+accountList.get(j).transactions.get(j).getDate());
			    System.out.println("The Type is "+accountList.get(j).transactions.get(j).getType());
			    System.out.println("The Amount is "+accountList.get(j).transactions.get(j).getAmount());
			    System.out.println("The Balance is "+accountList.get(j).transactions.get(j).getBalance());
			    System.out.println("The Description is "+accountList.get(j).transactions.get(j).getDescription());
				} 
			}
		}
		menu(id);
	}

	// 更改密码
	public static void changePassword(int id) {
		int i=0;
		for(i=0;i<accountList.size();i++){
			if(accountList.get(i).getId()==id)
				break;
		}
		int flag = 0;
		input.nextLine();
		while (true) {
			System.out.println("请输入原密码：");
			String oldPassword = input.nextLine();
			if (accountList.get(i).getPassword().equals(oldPassword)) {
				continueNewPassword: while (true) {
					System.out.println("请输入新的密码：");
					String newPassword = input.nextLine();
					if (oldPassword.equals(newPassword)) {
						System.out.println("新密码不能和旧密码相同，请重新输入！");
						continue continueNewPassword;
					} else {
						System.out.println("请再次确认新的密码：");
						String newPasswordAgain = input.nextLine();
						if (newPasswordAgain.equals(newPassword)) {
							accountList.get(i).setPassword(newPasswordAgain);
							try {
								writeToFile(accountList);
							} catch (FileNotFoundException e) {
								e.printStackTrace();
							} catch (IOException e) {
								e.printStackTrace();
							}
							System.out.println("恭喜您，修改密码成功！");
							flag = 1;
							break;
						} else {
							System.out.println("对不起，输入错误，请重新输入！");
							continue;
						}
					}
				}
				if (flag == 1)
					break;
			} else {
				System.out.println("输入有误，请重新输入！");
				continue;
			}
		}
	}

	// 退出
	public static void exit() throws ClassNotFoundException, FileNotFoundException, IOException {
		menu(id);
	}
}
