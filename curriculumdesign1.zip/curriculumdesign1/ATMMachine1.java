package curriculumdesign1;

public class ATMMachine1 {
	// 创建100个账户
	private static Account1[] accounts1 = new Account1[100];

	public static void main(String[] args) {
		for (int i = 0; i < accounts1.length; i++) {
			accounts1[i] = new Account1();
			accounts1[i].setId(i);
			accounts1[i].setBalance(1000);
		}
		int idNum = input();
		menu(idNum);
	}

	private static java.util.Scanner input = new java.util.Scanner(System.in);
	static int id;

	public static int input() {
		boolean flag = false;
		do {
			try {
				while (true) {
					System.out.print("Enter an id: ");
					id = input.nextInt();
					if (id < 1 || id > 100) {
						System.out.println("Input wrong,please input again!");
						continue;
					} else {
						flag = true;
						break;
					}
				}
			} catch (Exception ex) {
				System.out.println("Input wrong,please input again!");
				flag = false;
				input.nextLine();
			}
		} while (flag == false);
		return id;
	}

	public static void menu(int idNum) {
		int choice = 0;

		while (true) {
			System.out.println("Main menu");
			System.out.println("1: check balance ");
			System.out.println("2: withdraw ");
			System.out.println("3: deposit ");
			System.out.println("4: exit ");
			System.out.print("Enter a choice: ");
			choice = input.nextInt();
			if (choice < 1 || choice > 4) {
				System.out.println("Wrong choice, try again: ");
			} else {
				break;
			}
		}
		switch (choice) {
		case 1:
			balance(idNum);
			break;
		case 2:
			withdraw(idNum);
			break;
		case 3:
			deposit(idNum);
			break;
		case 4:
			exit();
			break;
		}
	}

	public static void balance(int id) {
		System.out.print("The balance is " + accounts1[id].getBalance());
		System.out.println();
		menu(id);
	}

	public static void withdraw(int id) {
		System.out.print("Enter an amount to withdraw: ");
		int amount = input.nextInt();
		if (amount <= accounts1[id].getBalance()&&amount>0) {
			accounts1[id].withdraw(amount);
		} else {
			System.out.print("The amount is too large, ignored");
		}
		menu(id);
	}

	public static void deposit(int id) {
		System.out.print("Enter an amount to deposit: ");
		int amount = input.nextInt();
		if (amount >= 0) {
			accounts1[id].deposit(amount);
		} else {
			System.out.print("The amount is negative, ignored");
		}
		menu(id);
	}

	public static void exit() {
		input();
		menu(id);
	}
}
