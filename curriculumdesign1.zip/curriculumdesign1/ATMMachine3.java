package curriculumdesign1;

import javafx.scene.control.TextField;
import java.util.regex.Pattern;

import javafx.event.EventHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import java.util.ArrayList;

import javafx.scene.Scene;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ATMMachine3 extends Application implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static Stage shareprimaryStage;
	public static int loginFlag = 0;
	public static int functionFlag = 0;
	static TextField p1 = new TextField();
	static PasswordField p2 = new PasswordField();

	static Button[] numberButtons = { new Button("  1  "), // 共用的小键盘按钮
			new Button("  2   "), new Button("  3  "), new Button("  4  "), new Button("  5   "), new Button("  6  "),
			new Button("  7  "), new Button("  8   "), new Button("  9  "), new Button("  0   "), new Button("退格"),
			new Button("清空") };

	public static void ButtonSkin(GridPane keyBordPane) { // 小键盘按钮格式

		numberButtons[0].setMinSize(40, 20);
		numberButtons[1].setMinSize(40, 20);
		numberButtons[2].setMinSize(40, 20);
		numberButtons[3].setMinSize(40, 20);
		numberButtons[4].setMinSize(40, 20);
		numberButtons[5].setMinSize(40, 20);
		numberButtons[6].setMinSize(40, 20);
		numberButtons[7].setMinSize(40, 20);
		numberButtons[8].setMinSize(40, 20);
		numberButtons[9].setMinSize(40, 20);
		numberButtons[10].setMinSize(40, 20);
		numberButtons[11].setMinSize(40, 20);

		keyBordPane.add(numberButtons[0], 0, 0);
		keyBordPane.add(numberButtons[1], 1, 0);
		keyBordPane.add(numberButtons[2], 2, 0);
		keyBordPane.add(numberButtons[3], 0, 1);
		keyBordPane.add(numberButtons[4], 1, 1);
		keyBordPane.add(numberButtons[5], 2, 1);
		keyBordPane.add(numberButtons[6], 0, 2);
		keyBordPane.add(numberButtons[7], 1, 2);
		keyBordPane.add(numberButtons[8], 2, 2);
		keyBordPane.add(numberButtons[9], 1, 3);
		keyBordPane.add(numberButtons[10], 0, 3);
		keyBordPane.add(numberButtons[11], 2, 3);

	}

	public static void respondButton(TextField fields) { // 响应小键盘按钮

		numberButtons[0].setOnAction(e1 -> {
			String s1 = fields.getText();
			fields.setText(s1 + "1");
		});

		numberButtons[1].setOnAction(e1 -> {
			String s2 = fields.getText();
			fields.setText(s2 + "2");
		});

		numberButtons[2].setOnAction(e1 -> {
			String s3 = fields.getText();
			fields.setText(s3 + "3");
		});

		numberButtons[3].setOnAction(e1 -> {
			String s4 = fields.getText();
			fields.setText(s4 + "4");
		});

		numberButtons[4].setOnAction(e1 -> {
			String s5 = fields.getText();
			fields.setText(s5 + "5");
		});

		numberButtons[5].setOnAction(e1 -> {
			String s6 = fields.getText();
			fields.setText(s6 + "6");
		});

		numberButtons[6].setOnAction(e1 -> {
			String s7 = fields.getText();
			fields.setText(s7 + "7");
		});

		numberButtons[7].setOnAction(e1 -> {
			String s8 = fields.getText();
			fields.setText(s8 + "8");
		});

		numberButtons[8].setOnAction(e1 -> {
			String s9 = fields.getText();
			fields.setText(s9 + "9");
		});

		numberButtons[9].setOnAction(e1 -> {// 退格
			String s10 = fields.getText();
			fields.setText(s10 + "0");
		});

		numberButtons[10].setOnAction(e1 -> {
			String s11 = fields.getText();
			try {
				fields.setText(s11.substring(0, s11.length() - 1));
			} catch (Exception e) {
			}
		});

		numberButtons[11].setOnAction(e1 -> {// 清空
			String s12 = fields.getText();
			fields.setText(s12.substring(s12.length()));
		});
	}

	@Override
	public void start(Stage primaryStage) throws Exception { // 开始的方法
		shareprimaryStage = primaryStage;
		login();
	}

	public static void login() { // 登录界面
		GridPane pane = new GridPane();
		GridPane keyBordPane = new GridPane();
		BorderPane blankPane = new BorderPane();
		pane.setAlignment(Pos.CENTER);
		keyBordPane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		pane.setHgap(5.5);
		pane.setVgap(5.5);

		// Place nodes in the pane
		pane.add(new Label("中国建设银行ATM"), 1, 0);
		pane.add(new Label("账号: "), 0, 7);
		pane.add(p1, 1, 7);

		pane.add(new Label("密码: "), 0, 8);
		pane.add(p2, 1, 8);

		p1.setEditable(true);
		p2.setEditable(true);

		Button btLogin = new Button("登录");
		pane.add(btLogin, 1, 10);
		GridPane.setHalignment(btLogin, HPos.LEFT);
		btLogin.setOnAction(e -> {
			String nowUsername = p1.getText();
			String nowPassword = p2.getText();
			System.out.println(nowUsername);
			System.out.println(nowPassword);
			accountsJudgement(nowUsername, nowPassword);
		});

		Button btRegister = new Button("注册");
		pane.add(btRegister, 1, 10);
		GridPane.setHalignment(btRegister, HPos.RIGHT);
		btRegister.setOnAction(e -> {
			try {
				register();
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		});

		Button btExit = new Button("退出");
		pane.add(btExit, 1, 13);
		GridPane.setHalignment(btExit, HPos.RIGHT);
		btExit.setOnAction(e -> {
			Alert warningAlert = new Alert(AlertType.INFORMATION);
			warningAlert.setTitle("Information Dialog");
			warningAlert.setHeaderText("Look,an Information Dialog");
			warningAlert.setContentText("欢迎下次使用，再见！");
			warningAlert.showAndWait();
			System.exit(0);// 退卡
		});
		ButtonSkin(keyBordPane);// 键盘面板

		p1.setOnMouseClicked(e -> {
			respondButton(p1);
		});

		p2.setOnMouseClicked(e -> {
			respondButton(p2);
		});

		blankPane.setCenter(pane);
		blankPane.setBottom(keyBordPane);

		// Create a scene and place it in the stage
		Scene scene = new Scene(blankPane, 400, 300);
		shareprimaryStage.setTitle("登录");
		shareprimaryStage.setScene(scene);
		shareprimaryStage.show();
	}

	static int judgementFlags = 0;

	public static void register() throws FileNotFoundException, IOException, ClassNotFoundException { // 用于注册用户信息

		Account2 account2 = new Account2();
		GridPane pane = new GridPane();
		GridPane keyBordPane = new GridPane();
		BorderPane blankPane = new BorderPane();
		Pattern pattern = Pattern.compile("[0-9]*");//正则表达式进行判断输入的字符
		pane.setAlignment(Pos.CENTER);
		keyBordPane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		pane.setHgap(5.5);
		pane.setVgap(5.5);
		pane.add(new Label("中国建设银行ATM"), 1, 0);

		pane.add(new Label("请输入账号："), 0, 3);
		TextField p7 = new TextField();
		pane.add(new Label("请输入密码："), 0, 5);
		PasswordField p8 = new PasswordField();
		pane.add(new Label("请再次输入密码："), 0, 7);
		PasswordField p9 = new PasswordField();
		pane.add(p7, 1, 3);
		pane.add(p8, 1, 5);
		pane.add(p9, 1, 7);

		ButtonSkin(keyBordPane);// 键盘面板

		Button rightButton = new Button("注册");
		Button backButton = new Button("返回");
		pane.add(rightButton, 1, 10);
		GridPane.setHalignment(rightButton, HPos.LEFT);
		GridPane.setHalignment(backButton, HPos.RIGHT);
		pane.add(backButton, 1, 10);

		p7.setOnMouseClicked(e -> {
			respondButton(p7);
		});

		p8.setOnMouseClicked(e -> {
			respondButton(p8);
		});
		p9.setOnMouseClicked(e -> {
			respondButton(p9);
		});
		// 打开文件，目的在于防止用户创建同名账户
		
		rightButton.setOnAction(e -> {
			File file=new File("D:/account.dat");
			ArrayList<Account2> accountList1=null;
			ObjectInputStream is=null;
			if(file.length()>0){
			try {
				is = new ObjectInputStream(new FileInputStream(file));
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			 try {
				accountList1=(ArrayList<Account2>)is.readObject();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}	
			}
			else{
				 accountList1=new ArrayList<Account2>(0);
			}
			if (pattern.matcher(p7.getText()).matches() && p7.getText().length() == 6) {
				for (int i = 0; i < accountList1.size(); i++) {
					if (accountList1.get(i).getName().equals(p7.getText()) == false) {
						judgementFlags++;
					}
				}
				if (judgementFlags == accountList1.size()) {
						account2.setName(p7.getText());
					if (p8.getText().equals(p9.getText())) {
						if (p8.getText().length() == 6) {
							account2.setPassword(p8.getText());
							accountList1.add(account2);
							try {
								if(file.length()!=0)
								is.close();
								writeToFile(accountList1);

							} catch (FileNotFoundException e1) {
								e1.printStackTrace();
							} catch (IOException e1) {
								e1.printStackTrace();
							}

							Alert warningAlert = new Alert(AlertType.INFORMATION);
							warningAlert.setTitle("Information Dialog");
							warningAlert.setHeaderText("Look,an Information Dialog");
							warningAlert.setContentText("注册成功");
							warningAlert.showAndWait();
							login();
						} else {
							Alert warningAlert = new Alert(AlertType.ERROR);
							warningAlert.setTitle("Error Dialog");
							warningAlert.setHeaderText("Look,an Error Dialog");
							warningAlert.setContentText("密码需为6位纯数字组成");
							warningAlert.showAndWait();
						}

					} else {
						Alert warningAlert = new Alert(AlertType.ERROR);
						warningAlert.setTitle("Error Dialog");
						warningAlert.setHeaderText("Look,an Error Dialog");
						warningAlert.setContentText("两次输入密码不同，请重新输入!");
						warningAlert.showAndWait();
					}
				} else {
					Alert warningAlert = new Alert(AlertType.ERROR);
					warningAlert.setTitle("Error Dialog");
					warningAlert.setHeaderText("Look,an Error Dialog");
					warningAlert.setContentText("账号与文件中用户名相同，请重新输入！");
					warningAlert.showAndWait();
				}

			} else {
				Alert warningAlert = new Alert(AlertType.ERROR);
				warningAlert.setTitle("Error Dialog");
				warningAlert.setHeaderText("Look,an Error Dialog");
				warningAlert.setContentText("账号需为6位纯数字组成");
				warningAlert.showAndWait();
			}
		});
		backButton.setOnAction(e -> {
			login();
		});
		blankPane.setCenter(pane);
		blankPane.setBottom(keyBordPane);
		Scene scene = new Scene(blankPane, 400, 300);
		shareprimaryStage.setTitle("登录");
		shareprimaryStage.setScene(scene);
		shareprimaryStage.show();
	}

	private static int listPos = 0;

	public static void accountsJudgement(String nowUsername, String nowPassword) { // 用于判断文件中的账户和密码时候匹配
		int judgementFlag = 0, flag = 0;
		//login();
		try {
			ObjectInputStream is = new ObjectInputStream(new FileInputStream("D:/account.dat"));
			@SuppressWarnings("unchecked")
			ArrayList<Account2> accountList = (ArrayList<Account2>) is.readObject();
			
			for (int i = 0; i < accountList.size(); i++) {
				if (accountList.get(i).getName().equals(nowUsername)) {
					if (accountList.get(i).getPassword().equals(nowPassword)) {
						listPos = i;
						judgementFlag = 1;
						loginInterface(judgementFlag);
					} else {
						Alert warningAlert = new Alert(AlertType.ERROR);
						warningAlert.setTitle("Error Dialog");
						warningAlert.setHeaderText("Look,an Error Dialog");
						warningAlert.setContentText("密码错误！");
						warningAlert.showAndWait();
					}
				} else {
					flag++;
				}
			}
			if (flag == accountList.size()) {
				Alert warningAlert = new Alert(AlertType.ERROR);
				warningAlert.setTitle("Error Dialog");
				warningAlert.setHeaderText("Look,an Error Dialog");
				warningAlert.setContentText("用户名不存在！");
				warningAlert.showAndWait();
			}
			is.close();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static void loginInterface(int flag) { // 登录成功后的界面
		GridPane panes = new GridPane();
		panes.setAlignment(Pos.CENTER);
		if (flag == 1) {
			Label welcomeLabel = new Label("欢迎使用中国建设银行ATM机");
			welcomeLabel.setContentDisplay(ContentDisplay.CENTER);
			Button[] functionButtons = { new Button("余额查询"), new Button("交易记录"), new Button("更改密码"), new Button("存款"),
					new Button("取款"), new Button("退卡") };
			panes.setPadding(new Insets(15, 15, 15, 15));
			panes.setHgap(15);
			panes.setVgap(15);
			panes.add(functionButtons[0], 0, 0);
			GridPane.setHalignment(functionButtons[0], HPos.LEFT);
			panes.add(functionButtons[1], 0, 1);
			GridPane.setHalignment(functionButtons[1], HPos.LEFT);
			panes.add(functionButtons[2], 0, 2);
			GridPane.setHalignment(functionButtons[2], HPos.LEFT);
			panes.add(functionButtons[3], 5, 0);
			GridPane.setHalignment(functionButtons[3], HPos.RIGHT);
			panes.add(functionButtons[4], 5, 1);
			GridPane.setHalignment(functionButtons[4], HPos.RIGHT);
			panes.add(functionButtons[5], 5, 2);
			GridPane.setHalignment(functionButtons[5], HPos.RIGHT);
			functionButtons[0].setOnAction(new SelectFunction(0));// 余额查询
			functionButtons[1].setOnAction(new SelectFunction(1));// 交易记录
			functionButtons[2].setOnAction(new SelectFunction(2));// 更改密码
			functionButtons[3].setOnAction(new SelectFunction(3));// 存款
			functionButtons[4].setOnAction(new SelectFunction(4));// 取款
			functionButtons[5].setOnAction(e -> {
				Alert warningAlert = new Alert(AlertType.INFORMATION);
				warningAlert.setTitle("Information Dialog");
				warningAlert.setHeaderText("Look,an Information Dialog");
				warningAlert.setContentText("欢迎下次使用，再见！");
				warningAlert.showAndWait();
				System.exit(0);// 退卡
			});
			Scene newScene = new Scene(panes, 400, 300);
			shareprimaryStage.setTitle("中国建设银行ATM机");
			shareprimaryStage.setScene(newScene);
			shareprimaryStage.show();
		}

	}

	static class SelectFunction implements EventHandler<ActionEvent> {
		int selectFlag;

		public SelectFunction(int flag) {
			super();
			this.selectFlag = flag;
		}

		@Override
		public void handle(ActionEvent event) {
			if (selectFlag == 0) {
				functionFlag = 0;
			} else if (selectFlag == 1) {
				functionFlag = 1;
			} else if (selectFlag == 2) {
				functionFlag = 2;
			} else if (selectFlag == 3) {
				functionFlag = 3;
			} else if (selectFlag == 4) {
				functionFlag = 4;
			}
			shareHandles(selectFlag);
		}
	}

	public static void shareHandles(int flag) { // 该方法用于实现登录成功后界面的各个功能
		int j = 0;// 用于设置交易记录中返回按钮的位置

		GridPane pane = new GridPane();
		GridPane keyBordPane = new GridPane();
		BorderPane blankPane = new BorderPane();
		pane.setAlignment(Pos.CENTER);
		keyBordPane.setAlignment(Pos.CENTER);
		Scene newScene = new Scene(blankPane, 700, 550);
		pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		pane.setHgap(5.5);
		pane.setVgap(5.5);

		Button rightButton = new Button("确认");
		Button backButton = new Button("返回");

		try {//读取文件内容
			ObjectInputStream is = new ObjectInputStream(new FileInputStream("D:/account.dat"));
			@SuppressWarnings("unchecked")
			ArrayList<Account2> accountList = (ArrayList<Account2>) is.readObject();
			if (flag == 0 || flag == 1) {
				if (flag == 0) { // 账户余额查询模块
					Label balanceLabel = new Label("账户余额：" + accountList.get(listPos).getBalance());
					pane.add(balanceLabel, 0, 7);
					pane.add(backButton, 2, 20);
					GridPane.setHalignment(backButton, HPos.RIGHT);
					backButton.setOnAction(e -> {
						loginInterface(1);
					});
				} else { // 交易记录查询模块
					Label tradingLabel = new Label("交易记录：");
					ArrayList<Transaction> nowTransactions = (ArrayList<Transaction>) accountList.get(listPos)
							.getTransactions();

					String[] transTexts = new String[nowTransactions.size()];
					ListView<String> listView = new ListView<String>();

					for (int k = 0; k < nowTransactions.size(); k++) {
						transTexts[k] = "1.The Date is: " + nowTransactions.get(k).getDate() + "\n2.The Balance is: "
								+ nowTransactions.get(k).getBalance() + "\n3.The Amount is: "
								+ nowTransactions.get(k).getAmount() + "\n4.The Type is: "
								+ nowTransactions.get(k).getType() + "\n5.The Description is: "
								+ nowTransactions.get(k).getDescription();
						j += (k + 5);
					}

					ObservableList<String> itemsList = FXCollections.observableArrayList(transTexts);
					listView.setItems(itemsList);
					listView.setPrefSize(500, 700);
					pane.add(listView, 2, 2);
					pane.add(tradingLabel, 1, 1);
					pane.add(backButton, 2, j - j / 2);
					GridPane.setHalignment(backButton, HPos.RIGHT);
					backButton.setOnAction(e -> {
						loginInterface(1);
					});
				}
			} else if (flag == 3 || flag == 4) {
				if (flag == 4) { // 取钱模块
					Label withdrawLabel = new Label("请输入取钱金额：");
					pane.add(withdrawLabel, 0, 5);
					TextField p3 = new TextField();
					pane.add(rightButton, 1, 10);

					rightButton.setOnAction(e -> {
						String withdrawMoney = p3.getText();
						Double moneyDouble = Double.parseDouble(withdrawMoney);

						if (p3.getText().isEmpty() == false && moneyDouble % 100 == 0) {
							if (moneyDouble > accountList.get(listPos).getBalance() || moneyDouble >= 5000) {
								Alert warningAlert = new Alert(AlertType.ERROR);
								warningAlert.setTitle("Error Dialog");
								warningAlert.setHeaderText("Look,an Error Dialog");
								warningAlert.setContentText("一次性取款超过5000元或余额不足！");
								warningAlert.showAndWait();
							} else {
								if(moneyDouble>0){
									accountList.get(listPos).withDraw(moneyDouble, "");
									try {
										writeToFile(accountList);
									} catch (FileNotFoundException e1) {
										e1.printStackTrace();
									} catch (IOException e1) {
										e1.printStackTrace();
									}
	
									Alert warningAlert = new Alert(AlertType.INFORMATION);
									warningAlert.setTitle("Information Dialog");
									warningAlert.setHeaderText("Look,an Information Dialog");
									warningAlert.setContentText("取款成功");
									warningAlert.showAndWait();
									loginInterface(1);
									}else {
										Alert warningAlert = new Alert(AlertType.ERROR);
										warningAlert.setTitle("Error Dialog");
										warningAlert.setHeaderText("Look,an Error Dialog");
										warningAlert.setContentText("取款为负数，请重新输入！");
										warningAlert.showAndWait();
									}
							}
						} else {
							Alert warningAlert = new Alert(AlertType.ERROR);
							warningAlert.setTitle("Error Dialog");
							warningAlert.setHeaderText("Look,an Error Dialog");
							warningAlert.setContentText("输入为空或取钱不为100的整数倍！");
							warningAlert.showAndWait();
						}

					});
					pane.add(p3, 1, 5);
					pane.add(backButton, 1, 10);
					GridPane.setHalignment(backButton, HPos.RIGHT);
					ButtonSkin(keyBordPane);
					respondButton(p3);
					backButton.setOnAction(e -> {
						loginInterface(1);
					});
				} else { // 存钱模块
					Label despositLabel = new Label("请输入存钱金额：");
					pane.add(despositLabel, 0, 5);
					TextField p4 = new TextField();
					pane.add(rightButton, 1, 10);

					rightButton.setOnAction(e -> {
						String despositMoney = p4.getText();
						Double moneyDouble = Double.parseDouble(despositMoney);
						if (p4.getText().isEmpty() == false && moneyDouble % 100 == 0) {
							if (moneyDouble >= 5000) {
								Alert warningAlert = new Alert(AlertType.ERROR);
								warningAlert.setTitle("Error Dialog");
								warningAlert.setHeaderText("Look,an Error Dialog");
								warningAlert.setContentText("一次性存款不能超过5000元！");
								warningAlert.showAndWait();
							} else {
									if(moneyDouble>0){
									accountList.get(listPos).deposit(moneyDouble, "");
									try {
										writeToFile(accountList);
									} catch (FileNotFoundException e1) {
										e1.printStackTrace();
									} catch (IOException e1) {
										e1.printStackTrace();
									}
	
									Alert warningAlert = new Alert(AlertType.INFORMATION);
									warningAlert.setTitle("Information Dialog");
									warningAlert.setHeaderText("Look,an Information Dialog");
									warningAlert.setContentText("存款成功");
									warningAlert.showAndWait();
									loginInterface(1);
								}else {
									Alert warningAlert = new Alert(AlertType.ERROR);
									warningAlert.setTitle("Error Dialog");
									warningAlert.setHeaderText("Look,an Error Dialog");
									warningAlert.setContentText("存款为负数，请重新输入！");
									warningAlert.showAndWait();
								}
							}
						} else {
							Alert warningAlert = new Alert(AlertType.ERROR);
							warningAlert.setTitle("Error Dialog");
							warningAlert.setHeaderText("Look,an Error Dialog");
							warningAlert.setContentText("输入为空或存钱不为100的整数倍！");
							warningAlert.showAndWait();
						}

					});
					pane.add(p4, 1, 5);
					pane.add(backButton, 1, 10);
					GridPane.setHalignment(backButton, HPos.RIGHT);
					ButtonSkin(keyBordPane);
					respondButton(p4);
					backButton.setOnAction(e -> {
						loginInterface(1);
					});
				}
			} else if (flag == 2) { // 更改密码模块

				pane.add(new Label("请输入新密码："), 0, 5);
				PasswordField p5 = new PasswordField();

				pane.add(new Label("请再次输入新密码："), 0, 7);
				PasswordField p6 = new PasswordField();

				pane.add(p5, 1, 5);
				pane.add(p6, 1, 7);
				pane.add(rightButton, 1, 10);

				rightButton.setOnAction(e -> {
					if (accountList.get(listPos).getPassword().equals(p5.getText()) == false) {
						if (p5.getText().equals(p6.getText()) && p5.getText().isEmpty() == false) {
							if (p5.getText().length() == 6) {
								accountList.get(listPos).setPassword(p6.getText());

								try {
									writeToFile(accountList);
								} catch (FileNotFoundException e1) {
									e1.printStackTrace();
								} catch (IOException e1) {
									e1.printStackTrace();
								}
								// 提示窗口
								Alert warningAlert = new Alert(AlertType.INFORMATION);
								warningAlert.setTitle("Information Dialog");
								warningAlert.setHeaderText("Look,an Information Dialog");
								warningAlert.setContentText("修改成功");
								warningAlert.showAndWait();
								loginInterface(1);
							} else {
								Alert warningAlert = new Alert(AlertType.ERROR);
								warningAlert.setTitle("Error Dialog");
								warningAlert.setHeaderText("Look,an Error Dialog");
								warningAlert.setContentText("密码为6位纯数字！");
								warningAlert.showAndWait();
							}

						} else {
							Alert warningAlert = new Alert(AlertType.ERROR);
							warningAlert.setTitle("Error Dialog");
							warningAlert.setHeaderText("Look,an Error Dialog");
							warningAlert.setContentText("密码与上次输入不符或为空！");
							warningAlert.showAndWait();
							shareHandles(2);
						}
					} else {
						Alert warningAlert = new Alert(AlertType.ERROR);
						warningAlert.setTitle("Error Dialog");
						warningAlert.setHeaderText("Look,an Error Dialog");
						warningAlert.setContentText("新密码不能和原密码相同！");
						warningAlert.showAndWait();
						shareHandles(2);
					}
				});
				pane.add(backButton, 1, 10);
				GridPane.setHalignment(backButton, HPos.RIGHT);
				ButtonSkin(keyBordPane);
				// 用鼠标点击事件响应小键盘
				p5.setOnMouseClicked(e -> {
					respondButton(p5);
				});

				p6.setOnMouseClicked(e -> {
					respondButton(p6);
				});
				backButton.setOnAction(e -> {
					loginInterface(1);
				});
			}

			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		blankPane.setCenter(pane);
		blankPane.setBottom(keyBordPane);

		shareprimaryStage.setTitle("中国建设银行ATM机");
		shareprimaryStage.setScene(newScene);
		shareprimaryStage.show();
	}

	// 存盘函数
	public static void writeToFile(ArrayList<Account2> accountList) throws FileNotFoundException, IOException {
		ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("D:/account.dat", false));
		os.writeObject(accountList);
		os.close();
	}

	// 主函数模块
	public static void main(String[] args) {
		Application.launch(args);
	}
}
