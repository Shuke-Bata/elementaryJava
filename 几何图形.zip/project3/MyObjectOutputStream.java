package namespace2;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
class MyObjectOutputStream extends ObjectOutputStream {
	public MyObjectOutputStream(FileOutputStream out) throws IOException {
		super(out);
	}

	protected void writeStreamHeader() throws IOException {
		System.out.println(" ");
		return;
	}
}
