package namespace2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.DecimalFormat;

import namespace1.IllegalTrianleException;

public class Triangle implements GeometricObject, java.io.Serializable {
	private double side1 = 1.0;
	private double side2 = 1.0;
	private double side3 = 1.0;
	private String color = null;
	private boolean filled = false;
	private java.util.Date dateCreated;
	public final DecimalFormat printFormat = new DecimalFormat("0.00");

	public Triangle() {

	}

	public Triangle(double side1, double side2, double side3, String color, boolean filled)
			throws IllegalTrianleException {
		this.setSide(side1, side2, side3);
		this.setColor(color);
		this.setFilled(filled);
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getColor() {
		return this.color;
	}

	public boolean isFilled() {
		return this.filled;
	}

	public void setFilled(boolean filled) {
		this.filled = filled;
	}

	public void setSide(double side1, double side2, double side3) throws IllegalTrianleException {
		if (side1 + side2 <= side3 || side2 + side3 <= side1 || side1 + side3 <= side2)
			throw new IllegalTrianleException();
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
	}

	public double[] getSide() {
		double side[]=new double[3];
		side[0]= Double.parseDouble(printFormat.format(side1));
		side[1]= Double.parseDouble(printFormat.format(side2));
		side[2]= Double.parseDouble(printFormat.format(side3));
		return side;
	}

	public double getArea() {
		double s = (side1 + side2 + side3) / 2;
		return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
	}

	public double getPerimeter() {
		return side1 + side2 + side3;
	}

	public String toString() {
		return "Triangle : side1 =" + printFormat.format(side1) + " side2 =" + printFormat.format(side2) + " side3 ="
				+ printFormat.format(side3) + " color = " + this.getColor() + "  filled = " + this.isFilled()
				+ " area = " + printFormat.format(getArea()) + " perimeter = " + printFormat.format(getPerimeter());
	}

	public void draw(String color) {
		this.setColor(color);
	}

	public void erase() {
		this.setColor(null);
	}
	
	public void writeToFile(File f) throws IOException {
		FileOutputStream out=null;
		ObjectOutputStream output=null;
		try {
			out = new FileOutputStream(f, false);
			output = new ObjectOutputStream(out);
			output.writeObject(this);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			output.close();
			out.close();
		}
	}
}
