package namespace3;

import java.io.IOException;

import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.ShadowBuilder;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.TriangleMesh;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import namespace1.IllegalCircleException;
import namespace1.IllegalTrianleException;
import namespace2.IllegalRectangleException;

public class GUIGeometric extends Application implements EventHandler<ActionEvent> {
	public static int getGeometric = 0;																			//����ȫ�ֵļ����ź�
	static Stage UnitprimaryStage;												//���ù�����̨��ȫ��ʹ��
	static boolean Unitflag=false;
	public void handle(ActionEvent e) {							//����̨����Ӧ��
		this.start(UnitprimaryStage);
	}
	static final String colorList[]={ "red","black","golden","yellow","green","white","gray", "brown","blue","purple","orangle","pink","null"};
	public void start(Stage primaryStage) {
		UnitprimaryStage = primaryStage;
		FlowPane pane = new FlowPane();
		Button[] button1 = { new Button("Բ��"), new Button("������"), new Button("����"), new Button("�˳�") };
		pane.setPadding(new Insets(15, 15, 15, 15));
		pane.getChildren().addAll(button1);
		pane.setHgap(15);
		pane.setVgap(15);
		button1[0].setOnAction(new selectFunbt(0));
		button1[1].setOnAction(new selectFunbt(1));
		button1[2].setOnAction(new selectFunbt(2));
		button1[3].setOnAction(e -> {
			System.exit(0);
		});
		Scene scene = new Scene(pane, 300, 50);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
							/*ʹ�����Ҷ������������ε�����*/
	public static double[][] pointCoo(double side1, double side2, double side3) {
		double[][] coo = new double[2][2];
		double cosC = (Math.pow(side1, 2) + Math.pow(side2, 2) - Math.pow(side3, 2)) / (2 * side1 * side2);
		double rad = Math.acos(cosC);
		double halfrad = rad / 2;
		coo[0][0] = Math.sin(halfrad) * side1;
		coo[0][1] = Math.cos(halfrad) * side1;
		coo[1][0] = Math.sin(halfrad) * side2;
		coo[1][1] = Math.cos(halfrad) * side2;
		return coo;
	}
                         /*���Ƹ���ͼ��*/
	static class makebt implements EventHandler<ActionEvent> {
		TextField a;
		TextField b;
		TextField c;
		TextField d;
		TextField e;
		public makebt(TextField[] x) {
			super();
			if (getGeometric == 0) {
				a = x[0];
				b = x[1];
				c = x[2];
			} else if (getGeometric == 1) {
				a = x[0];
				b = x[1];
				c = x[2];
				d = x[3];
				e = x[4];
			} else {
				a = x[0];
				b = x[1];
				c = x[2];
				d = x[3];
			}
		}

		public void handle(ActionEvent e) {
			if (getGeometric == 0) {
				Circle circle = new Circle();
				namespace2.Circle makecircle = null;
				try {
					makecircle = new namespace2.Circle(Double.parseDouble(this.a.getText()), this.b.getText(),
							Boolean.parseBoolean(this.c.getText()));
					boolean tag=true;
					for(int i=0;i<12;i++){
						if(colorList[i].equals(this.b.getText()))
							tag=false;
					}
					if(tag)
						throw new NumberFormatException();
				} catch (NumberFormatException f) {
					new Textformat();
				} catch (IllegalCircleException f) {
					new Textformat();
				}
				BorderPane borderpane = new BorderPane();
				circle.setRadius(Double.parseDouble(this.a.getText()));
				circle.setStroke(chooseColor(this.b.getText()));
				if (Boolean.parseBoolean(this.c.getText()))
					circle.setFill(chooseColor(this.b.getText()));
				else {
					circle.setFill(null);
				}
				borderpane.setCenter(circle);
				HBox hBox = new HBox(Double.parseDouble(this.a.getText()) / 2);
				hBox.setPadding(new Insets(15, 15, 15, 15));
				Label label1 = new Label("�ܳ�  : " + makecircle.getPerimeter());
				Label label2 = new Label("���  : " + makecircle.getArea());
				Button rebutton = new Button(
						"                                                                                                           ����                              "
								+ "                                                                             ");
				Button remainbutton = new Button(
						"                                                                                                         ���˵�                              "
								+ "                                                                           ");
				VBox vbox = new VBox();	
				vbox.getChildren().addAll(rebutton, remainbutton);
				borderpane.setBottom(vbox);
				rebutton.setOnAction(new SelectGeometric(false));
				remainbutton.setOnAction(new GUIGeometric());
				hBox.getChildren().addAll(label1, label2);
				borderpane.setTop(hBox);
				Scene newscene = new Scene(borderpane, 1000, 700);
				UnitprimaryStage.setScene(newscene);
				UnitprimaryStage.show();
			} else if (getGeometric == 1) {
				Pane pane = new Pane();
				Polygon polygon = new Polygon();
				ObservableList<Double> list = polygon.getPoints();
				double centerX = 500, centerY = 70;
				list.add(centerX);
				list.add(centerY);
				double[][] offset = new double[2][2];
				namespace2.Triangle maketriangle = null;
				try{
				offset = pointCoo(Double.parseDouble(this.a.getText()), Double.parseDouble(this.b.getText()),
						Double.parseDouble(this.c.getText()));
				list.add(centerX - offset[0][0]);
				list.add(centerY + offset[0][1]);
				list.add(centerX + offset[1][0]);
				list.add(centerY + offset[1][1]);			
					maketriangle = new namespace2.Triangle(Double.parseDouble(this.a.getText()),
							Double.parseDouble(this.b.getText()), Double.parseDouble(this.c.getText()),
							this.d.getText(), Boolean.parseBoolean(this.e.getText()));
				} catch (NumberFormatException f) {
					new Textformat();
				} catch (IllegalTrianleException e1) {
					new Textformat();
				}
				polygon.setStroke(chooseColor(this.d.getText()));
				if (Boolean.parseBoolean(this.e.getText()))
					polygon.setFill(chooseColor(this.d.getText()));
				else {
					polygon.setFill(null);
				}
				Label label1 = new Label("�ܳ�  : " + maketriangle.getPerimeter());
				Label label2 = new Label("���  : " + maketriangle.getArea());
				label1.setLayoutX(100);
				label2.setLayoutX(200);
				label1.setLayoutY(70);
				label2.setLayoutY(70);
				Button rebutton = new Button(
						"                                                                                                           ����                              "
								+ "                                                                             ");
				Button remainbutton = new Button(
						"                                                                                                         ���˵�                              "
								+ "                                                                           ");
				remainbutton.setLayoutX(0);
				remainbutton.setLayoutY(670);
				rebutton.setLayoutX(0);
				rebutton.setLayoutY(640);
				rebutton.setOnAction(new SelectGeometric(false));
				remainbutton.setOnAction(new GUIGeometric());
				pane.getChildren().addAll(polygon, label1, label2, rebutton, remainbutton);
				Scene newscene = new Scene(pane, 1000, 700);
				UnitprimaryStage.setScene(newscene);
				UnitprimaryStage.show();
			} else {
				namespace2.Rectangle makerectangle = null;
				try {

					makerectangle = new namespace2.Rectangle(Double.parseDouble(this.a.getText()),
							Double.parseDouble(this.b.getText()), this.c.getText(),
							Boolean.parseBoolean(this.d.getText()));
				} catch (IllegalRectangleException e1) {
					new Textformat();
				} catch (NumberFormatException f) {
					new Textformat();
				} 
				BorderPane borderpane = new BorderPane();
				Rectangle rectangle = new Rectangle(500 - Double.parseDouble(this.a.getText()) / 2,
						350 - Double.parseDouble(this.b.getText()) / 2, Double.parseDouble(this.a.getText()),
						Double.parseDouble(this.a.getText()));
				rectangle.setStroke(chooseColor(this.c.getText()));
				if (Boolean.parseBoolean(this.d.getText()))
					rectangle.setFill(chooseColor(this.c.getText()));
				else {
					rectangle.setFill(null);
				}
				borderpane.setCenter(rectangle);
				HBox hBox = new HBox(Double.parseDouble(this.a.getText()) / 2);
				hBox.setPadding(new Insets(15, 15, 15, 15));
				Label label1 = new Label("�ܳ�  : " + makerectangle.getPerimeter());
				Label label2 = new Label("���  : " + makerectangle.getArea());
				Button rebutton = new Button(
						"                                                                                                           ����                              "
								+ "                                                                             ");
				Button remainbutton = new Button(
						"                                                                                                         ���˵�                              "
								+ "                                                                           ");
				VBox vbox = new VBox();
				vbox.getChildren().addAll(rebutton, remainbutton);
				borderpane.setBottom(vbox);
				rebutton.setOnAction(new SelectGeometric(false));
				remainbutton.setOnAction(new GUIGeometric());
				hBox.getChildren().addAll(label1, label2);
				borderpane.setTop(hBox);
				Scene newscene = new Scene(borderpane, 1000, 700);
				UnitprimaryStage.setScene(newscene);
				UnitprimaryStage.show();
			}
		}
	}
				/*��������ɫƥ��������Ӧ��Colorֵ*/
	public static Paint chooseColor(String color) {
		if (color.equals("red")) {
			return Color.RED;
		} else if (color.equals("black")) {
			return Color.BLACK;
		} else if (color.equals("pink")) {
			return Color.PINK;
		} else if (color.equals("yellow")) {
			return Color.YELLOW;
		} else if (color.equals("white")) {
			return Color.WHITE;
		} else if (color.equals("orange")) {
			return Color.ORANGE;
		} else if (color.equals("blue")) {
			return Color.BLUE;
		} else if (color.equals("purple")) {
			return Color.PURPLE;
		} else if (color.equals("green")) {
			return Color.GREEN;
		} else if (color.equals("gray")) {
			return Color.GRAY;
		} else if (color.equals("brown")) {
			return Color.BROWN;
		} else if (color.equals("golden")) {
			return Color.GOLDENROD;
		}
		return null;
	}
	/* �������ͼ�����ز���*/
	
	static class SelectGeometric implements EventHandler<ActionEvent> {
		 
		boolean s =false;
		public SelectGeometric(boolean a) {
			s = a;
		}

		public void handle(ActionEvent e) {
			final ChoiceBox cb = new ChoiceBox(FXCollections.observableArrayList(
					"red","black","golden","yellow","green","white","gray", "brown","blue","purple","orangle","pink","null")
				);
			final ChoiceBox cf = new ChoiceBox(FXCollections.observableArrayList(
					"true","false")
				);
		
			if (getGeometric == 0) {
				TextField radius = new TextField();
				TextField color = new TextField();
				TextField isfilled = new TextField();
				Button rebutton = new Button("����");
				rebutton.setStyle("-fx-border-color:blue");
				GridPane gridpane = new GridPane();
				gridpane.setHgap(5);
				gridpane.setVgap(5);
				gridpane.add(new Label("�뾶��"), 0, 0);
				gridpane.add(radius, 1, 0);
				gridpane.add(new Label("��ɫ��"), 0, 1);
				gridpane.add(color, 1, 1);
				gridpane.add(new Label("�Ƿ���䣺"), 0, 2);
				gridpane.add(isfilled, 1, 2);
				gridpane.setAlignment(Pos.BASELINE_CENTER);
				radius.setAlignment(Pos.BASELINE_RIGHT);
				color.setAlignment(Pos.BASELINE_RIGHT);
				isfilled.setAlignment(Pos.BASELINE_RIGHT);
				radius.setEditable(true);
				color.setEditable(true);
				isfilled.setEditable(true);	
				cb.getSelectionModel().selectedIndexProperty().addListener((ObservableValue<? extends Number>ov,Number old_val,Number new_val)->
				{   color.setText(colorList[new_val.intValue()]);});
				cf.getSelectionModel().selectedIndexProperty().addListener((ObservableValue<? extends Number>ov,Number old_val,Number new_val)->
				{   if(new_val.intValue()==0)
							isfilled.setText("true");	
					else
						isfilled.setText("false");	});
				gridpane.add(cb, 2, 1);
				gridpane.add(cf, 2, 2);
				if (s) {
					Button debutton = new Button("������ɾ��");
					Unitflag=true;
					gridpane.add(debutton, 1, 3);
					debutton.setOnAction(
							new deGeometric(new TextField[] { radius, color, isfilled }, getGeometric));
					GridPane.setHalignment(debutton, HPos.RIGHT);
				} else {
					Unitflag=false;
					Button makebutton = new Button("����");
					makebutton.setStyle("-fx-border-color:red");
					gridpane.add(makebutton, 1, 3);
					try{
					makebutton.setOnAction(new makebt(new TextField[] { radius, color, isfilled }));
					}catch( NumberFormatException r){
						new Textformat ();
					}
					GridPane.setHalignment(makebutton, HPos.RIGHT);
				}
				gridpane.add(rebutton, 0, 3);
				rebutton.setOnAction(new selectFunbt(getGeometric));
				Scene newscene1 = new Scene(gridpane, 400, 170);
				UnitprimaryStage.setScene(newscene1);
				UnitprimaryStage.show();
			} else if (getGeometric == 1) {
				TextField side1 = new TextField();
				TextField side2 = new TextField();
				TextField side3 = new TextField();
				TextField color = new TextField();
				TextField isfilled = new TextField();
				Button rebutton = new Button("����");
				rebutton.setStyle("-fx-border-color:red");
				GridPane gridpane = new GridPane();
				gridpane.setHgap(5);
				gridpane.setVgap(5);
				gridpane.add(new Label("��һ���ߣ�     "), 0, 0);
				gridpane.add(side1, 1, 0);
				gridpane.add(new Label("�ڶ����ߣ�     "), 0, 1);
				gridpane.add(side2, 1, 1);
				gridpane.add(new Label("�������ߣ�     "), 0, 2);
				gridpane.add(side3, 1, 2);
				gridpane.add(new Label("��ɫ��           "), 0, 3);
				gridpane.add(color, 1, 3);
				gridpane.add(new Label("�Ƿ���䣺     "), 0, 4);
				gridpane.add(isfilled, 1, 4);
				gridpane.add(rebutton, 0, 5);
				gridpane.setAlignment(Pos.BASELINE_CENTER);
				side1.setAlignment(Pos.BASELINE_RIGHT);
				side2.setAlignment(Pos.BASELINE_RIGHT);
				side3.setAlignment(Pos.BASELINE_RIGHT);
				color.setAlignment(Pos.BASELINE_RIGHT);
				isfilled.setAlignment(Pos.BASELINE_RIGHT);
				side1.setEditable(true);
				side2.setEditable(true);
				side3.setEditable(true);
				color.setEditable(true);
				isfilled.setEditable(true);
				cb.getSelectionModel().selectedIndexProperty().addListener((ObservableValue<? extends Number>ov,Number old_val,Number new_val)->
				{   color.setText(colorList[new_val.intValue()]);});
				cf.getSelectionModel().selectedIndexProperty().addListener((ObservableValue<? extends Number>ov,Number old_val,Number new_val)->
				{   if(new_val.intValue()==0)
							isfilled.setText("true");	
					else
						isfilled.setText("false");	});
				gridpane.add(cb, 2, 3);
				gridpane.add(cf, 2, 4);
				if (s) {
					Unitflag=true;
					Button debutton = new Button("������ɾ��");
					gridpane.add(debutton, 1, 5);
					debutton.setOnAction(
							new deGeometric(new TextField[] { side1, side2, side3, color, isfilled }, getGeometric));
					GridPane.setHalignment(debutton, HPos.RIGHT);
				} else {
					Unitflag=false;
					Button makebutton = new Button("����");
					makebutton.setStyle("-fx-border-color:red");
					gridpane.add(makebutton, 1, 5);
					makebutton.setOnAction(new makebt(new TextField[] { side1, side2, side3, color, isfilled }));
					GridPane.setHalignment(makebutton, HPos.RIGHT);
				}
				rebutton.setOnAction(new selectFunbt(getGeometric));
				Scene newscene1 = new Scene(gridpane, 450, 250);
				UnitprimaryStage.setScene(newscene1);
				UnitprimaryStage.show();
			} else {
				TextField width = new TextField();
				TextField length = new TextField();
				TextField color = new TextField();
				TextField isfilled = new TextField();
				Button rebutton = new Button("����");
				rebutton.setStyle("-fx-border-color:red");
				GridPane gridpane = new GridPane();
				gridpane.setHgap(5);
				gridpane.setVgap(5);
				gridpane.add(new Label("����              "), 0, 0);
				gridpane.add(length, 1, 0);
				gridpane.add(new Label("����              "), 0, 1);
				gridpane.add(width, 1, 1);
				gridpane.add(new Label("��ɫ��           "), 0, 2);
				gridpane.add(color, 1, 2);
				gridpane.add(new Label("�Ƿ���䣺     "), 0, 3);
				gridpane.add(isfilled, 1, 3);
				gridpane.setAlignment(Pos.BASELINE_CENTER);
				width.setAlignment(Pos.BASELINE_RIGHT);
				length.setAlignment(Pos.BASELINE_RIGHT);
				color.setAlignment(Pos.BASELINE_RIGHT);
				isfilled.setAlignment(Pos.BASELINE_RIGHT);
				width.setEditable(true);
				length.setEditable(true);
				color.setEditable(true);
				isfilled.setEditable(true);
				cb.getSelectionModel().selectedIndexProperty().addListener((ObservableValue<? extends Number>ov,Number old_val,Number new_val)->
				{   color.setText(colorList[new_val.intValue()]);});
				cf.getSelectionModel().selectedIndexProperty().addListener((ObservableValue<? extends Number>ov,Number old_val,Number new_val)->
				{   if(new_val.intValue()==0)
							isfilled.setText("true");	
					else
						isfilled.setText("false");	});
				gridpane.add(cb, 2, 2);
				gridpane.add(cf, 2, 3);
				if (s) {
					Unitflag=true;
					Button debutton = new Button("������ɾ��");
					gridpane.add(debutton, 1, 4);
					debutton.setOnAction(
							new deGeometric(new TextField[] { width, length, color, isfilled }, getGeometric));
					GridPane.setHalignment(debutton, HPos.RIGHT);
				} else {
					Unitflag=false;
					Button makebutton = new Button("����");
					makebutton.setStyle("-fx-border-color:red");
					gridpane.add(makebutton, 1, 4);
					makebutton.setOnAction(new makebt(new TextField[] { width, length, color, isfilled }));
					GridPane.setHalignment(makebutton, HPos.RIGHT);
				}
				gridpane.add(rebutton, 0, 4);
				rebutton.setOnAction(new selectFunbt(getGeometric));
				Scene newscene1 = new Scene(gridpane, 450, 250);
				UnitprimaryStage.setScene(newscene1);
				UnitprimaryStage.show();
			}
		}
	}
	/*����ѡ�����*/
	static class selectFunbt implements EventHandler<ActionEvent> {
			int s = 0;
		public selectFunbt(int a) {
			super();	
			this.s = a;
		}
		public void handle(ActionEvent e) {
			if (s == 0) {
				getGeometric = 0;
			} else if (s == 1) {
				getGeometric = 1;
			} else {
				getGeometric = 2;
			}
			unitHandle();
		}
	}
	
	public static void unitHandle() {
		Button[] button = { new Button("����"), new Button("ɾ��"), new Button("����") };
		FlowPane pane = new FlowPane();
		pane.setPadding(new Insets(15, 15, 15, 15));
		pane.setHgap(15);
		pane.setVgap(15);
		pane.getChildren().addAll(button);
		button[0].setOnAction(new SelectGeometric(Unitflag=false));
		button[1].setOnAction(new SelectGeometric(Unitflag=true));
		button[2].setOnAction(new GUIGeometric());
		Scene newscene = new Scene(pane, 250, 50);
		UnitprimaryStage.setScene(newscene);
		UnitprimaryStage.show();
	}
	/*ɾ����Ӧ�ļ���ͼ��*/
	static class deGeometric implements EventHandler<ActionEvent> {

		LinkData a;
		TextField[] c;
		int b;
		
		public deGeometric(TextField[] c, int b) {
			super();
			this.c = c;
			this.b = b;
		}

		public void handle(ActionEvent e) {
			try{
			a = new LinkData(c, b);
			Text text = null;
			Pane pane=new Pane();
			Button[] button={new Button("����"),new Button("���˵�")};
						try {
							if (a.deleteGeometricObject())
								text = new Text("ָ��������ɾ��");
							else
								text = new Text("ָ������δ�ҵ�");
						} catch (IOException | IllegalTrianleException | IllegalCircleException
								| IllegalRectangleException e1) {
							e1.printStackTrace();
						}
			text.setFill(Color.RED);
			text.setLayoutX(200);
			text.setLayoutY(75);
			pane.getChildren().add(text);
			button[0].setLayoutX(230);
			button[0].setLayoutY(200);
			button[1].setLayoutX(button[0].getLayoutX()-9);
			button[1].setLayoutY(button[0].getLayoutY()+35);
			button[0].setOnAction(new SelectGeometric(true));
			button[1].setOnAction(new GUIGeometric());
			pane.getChildren().addAll(button);
			Scene scene = new Scene(pane, 500, 300);
			UnitprimaryStage.setScene(scene);
			UnitprimaryStage.show();}
			catch(NumberFormatException t){
				new Textformat(); 
			}
		}
	}
	/*����ı������������Ƿ�Ϲ�*/
	public static class Textformat {
		public Textformat(  ){
			BorderPane pane=new BorderPane();
			Text text=new Text("       ��������      ");
			text.setFont(Font.font(40));
			text.setStroke(Color.RED);
			text.setFill(Color.RED);
			Button button=new Button("  �����������  ");
			System.out.println(Unitflag);
			button.setOnAction(new SelectGeometric(Unitflag));
			button.setAlignment(Pos.BOTTOM_CENTER);
			button.setMinSize(800, 20);
			pane.setCenter(text);
			pane.setBottom(button);
			Scene scene=new Scene(pane,800,500);
			UnitprimaryStage.setScene(scene);
			UnitprimaryStage.show();
		}
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}