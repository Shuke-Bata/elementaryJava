package namespace2;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Random;
import namespace1.IllegalCircleException;
import namespace1.IllegalTrianleException;

public class TestGeometricObject2 {
	public static String randomColor() {
		Random rand = new Random();
		int select = rand.nextInt(12);
		switch (select) {
		case 0:
			return "red";
		case 1:
			return "orangle";
		case 2:
			return "yellow";
		case 3:
			return "green";
		case 4:
			return "blue";
		case 5:
			return "purple";
		case 6:
			return "pink";
		case 7:
			return "black";
		case 8:
			return "white";
		case 9:
			return "gray";
		case 10:
			return "brown";
		case 11:
			return "golden";
		}
		return null;
	}

	public static Boolean randomCreateGeometricObject()
			throws IllegalTrianleException, IllegalCircleException, IOException, IllegalRectangleException {
		Random rand = new Random();
		int MU = Math.abs(rand.nextInt() % 100);
		File f = new File("E:\\GeometricObject.dat");
		ArrayList<Object> GeometricObject = new ArrayList<Object>();
		for (int i = 0; i < 12; i++) {
			try {
				if (rand.nextInt(3) == 0) {
					GeometricObject.add(new Triangle(rand.nextDouble() * MU, rand.nextDouble() * MU,
							rand.nextDouble() * MU, randomColor(), rand.nextBoolean()));
				} else if(rand.nextInt(3) == 1){
					GeometricObject.add(new Circle(rand.nextDouble() * MU, randomColor(), rand.nextBoolean()));
				}
				else{
					GeometricObject.add(new Rectangle(rand.nextDouble() * MU,rand.nextDouble() * MU, randomColor(), rand.nextBoolean()));
				}
			} catch (IllegalTrianleException e) {
				System.out.println("������Ч������");
			} catch (IllegalCircleException ex) {
				System.out.println("������ЧԲ��");
			}
			catch(IllegalRectangleException e){
				System.out.println("������Ч����");
			}
		}
		FileOutputStream out = null;
		ObjectOutputStream output = null;
		try {
			out = new FileOutputStream(f, false);
			output = new ObjectOutputStream(out);
			output.writeObject(GeometricObject);
		} catch (IOException e) {
			System.out.println("�������л�ʧ�ܣ�����");
			return false;
		} finally {
			output.close();
			out.close();
		}
		return true;
	}

	public static ArrayList<Object> readFile() throws IOException {
		ArrayList<Object> GeometricObject=null;
		FileInputStream in = null;
		ObjectInputStream input = null;
		try {
			in = new FileInputStream(new File("E:\\GeometricObject.dat"));
			input = new ObjectInputStream(in);
			ArrayList<Object> readObject = (ArrayList<Object>) input.readObject();
			GeometricObject = readObject;
			System.out.println("�ļ���ȡ��ɣ�����");
			for (Object i : GeometricObject) {
				System.out.println(i);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.exit(0);
		} catch (NullPointerException e) {
			System.out.println("�ļ�·���쳣������");
			System.exit(0);
		} catch (FileNotFoundException e) {

			System.out.println("�ļ���ȡʧ�ܣ�����");
			System.exit(0);
		} finally {
			in.close();
			input.close();
		}
		return GeometricObject;
	}

	public static void main(String[] args) throws Exception {
		randomCreateGeometricObject();
		readFile();
	}
}