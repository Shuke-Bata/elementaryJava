package namespace3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javafx.scene.control.TextField;
import namespace1.IllegalCircleException;
import namespace1.IllegalTrianleException;
import namespace2.Circle;
import namespace2.IllegalRectangleException;
import namespace2.Rectangle;
import namespace2.TestGeometricObject2;
import namespace2.Triangle;

public class LinkData {
	double[] inf = new double[3];
	int select;
	String color;
	boolean isfilled;
	public LinkData(TextField[] a, int select) {
		this.select = select;
		if (select == 0) {
			this.inf[0] = Double.parseDouble(a[0].getText());
			this.color = a[1].getText();
			this.isfilled = Boolean.parseBoolean(a[2].getText());
		} else if (select == 1) {
			this.inf[0] = Double.parseDouble(a[0].getText());
			this.inf[1] = Double.parseDouble(a[1].getText());
			this.inf[2] = Double.parseDouble(a[2].getText());
			this.color = a[3].getText();
			this.isfilled = Boolean.parseBoolean(a[4].getText());
		} else {
			this.inf[0] = Double.parseDouble(a[0].getText());
			this.inf[1] = Double.parseDouble(a[1].getText());
			this.color = a[2].getText();
			this.isfilled = Boolean.parseBoolean(a[3].getText());
		}
		boolean tag=true;
		for(int i=0;i<12;i++){
			if(GUIGeometric.colorList[i].equals(this.color))
				tag=false;
		}
		if(tag)
			throw new NumberFormatException();
	}
	public void saveToFile(ArrayList<Object> database) throws IOException{
		File file=new File("E:\\GeometricObject.dat");
		FileOutputStream out=new FileOutputStream(file,false);
		ObjectOutputStream output=new ObjectOutputStream(out);
		output.writeObject(database);
	}
	public boolean deleteGeometricObject()
			throws IOException, IllegalTrianleException, IllegalCircleException, IllegalRectangleException {
		ArrayList<Object> database = (ArrayList<Object>) TestGeometricObject2.readFile();
		if (this.select == 0) {
			for (int i = 0; i < database.size(); i++) {
				if (database.get(i) instanceof Circle) {
					if (((Circle) (database.get(i))).getRadius() == this.inf[0]
							&& ((Circle) (database.get(i))).getColor().equals(this.color)
							&& ((Circle) (database.get(i))).isFilled() == this.isfilled) {
						database.remove(i);
						saveToFile(database);
						return true;
					}
				}
			}
			return false;
		} else if (this.select == 1) {
			for (int i = 0; i < database.size(); i++) {
				if (database.get(i) instanceof Triangle) {
					double[] side=new double[3] ;
					side = ((Triangle) database.get(i)).getSide();
					if (side[0]+side[1]+side[2] == inf[2]+inf[0]+inf[1]&&Math.pow(side[0], 2)+Math.pow(side[1], 2)+Math.pow(side[2], 2)==
							Math.pow(inf[0], 2)+Math.pow(inf[1], 2)+Math.pow(inf[2], 2)
							&& ((Triangle) database.get(i)).getColor().equals(this.color)
							&& ((Triangle) database.get(i)).isFilled() == this.isfilled) {
						database.remove(i);
						saveToFile(database);
						return true;
					}
				}
			}
			return false;
		} else {
			for (int i = 0; i < database.size(); i++) {
				if (database.get(i) instanceof Rectangle) {
					double[] side = new double[2];
					side[0] = ((Rectangle) database.get(i)).getWidth();
					side[1] = ((Rectangle) database.get(i)).getLength();
					if (side[0] +side[1] == inf[1]+inf[0]&&Math.pow(side[0], 2)+Math.pow(side[1], 2)==Math.pow(inf[1], 2)+Math.pow(inf[0], 2)
							&& ((Rectangle) database.get(i)).getColor().equals(this.color)
							&& ((Rectangle) database.get(i)).isFilled() == this.isfilled) {
						database.remove(i);
						saveToFile(database);
						return true;
					}
				}
			}
			return false;
		}
	}
}
