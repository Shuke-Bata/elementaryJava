package namespace1;

import java.util.Random;

public  class TestGeometricObject1 {

	public static String randomColor() {
		Random rand = new Random();
		int select = rand.nextInt(12);
		switch (select) {
		case 0:
			return "red";
		case 1:
			return "orange";
		case 2:
			return "yellow";
		case 3:
			return "green";
		case 4:
			return "blue";
		case 5:
			return "purple";
		case 6:
			return "pink";
		case 7:
			return "black";
		case 8:
			return "whith";
		case 9:
			return "gray";
		case 10:
			return "brown";
		case 11:
			return "golden";
		}
		return null;
	}

	public static GeometricObject[] randomCreateGeometricObject()
			throws IllegalTrianleException, IllegalCircleException {
		Random rand = new Random();
		int MU = Math.abs(rand.nextInt() % 100);
		GeometricObject[] Geometric = new GeometricObject[5];
		for (int i = 0; i < 5; i++) {
			try {
				if (rand.nextInt() % 2 == 0) {
					Geometric[i] = new Triangle(rand.nextDouble() * MU,
							rand.nextDouble() * MU, rand.nextDouble() * MU,
							randomColor(), rand.nextBoolean());
				} else {
					Geometric[i] = new Circle(rand.nextDouble() * MU,
							randomColor(), rand.nextBoolean());
				}
			} catch (IllegalTrianleException e) {
				System.out.println("��Ч������");
			} catch (IllegalCircleException ex) {
				System.out.println("��ЧԲ��");
			}
		}
		return Geometric;
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		GeometricObject[] TestGeometric = randomCreateGeometricObject();
		for (GeometricObject i : TestGeometric) {
			if (i != null)
				System.out.println(i);
		}
	}

}
