package namespace2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Date;
import namespace1.IllegalCircleException;

public class Circle implements GeometricObject, java.io.Serializable {
	private String color = null;
	private boolean filled = false;
	private java.util.Date dateCreated;
	public final DecimalFormat printFormat = new DecimalFormat("0.00");
	private double radius;
	protected static final double PI = 3.14;

	public Circle() {
	}

	public Circle(double radius, String color, boolean filled) throws IllegalCircleException {
		this.setRadius(radius);
		this.setColor(color);
		this.setFilled(filled);
		dateCreated = new Date();
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isFilled() {
		return filled;
	}

	public void setFilled(boolean filled) {
		this.filled = filled;
	}

	public double getRadius() {
		return Double.parseDouble(printFormat.format(radius));
	}

	public void draw(String color) {
		this.setColor(color);
	}

	public void erase() {
		this.setColor(null);
	}

	public void setRadius(double radius) throws IllegalCircleException {
		if (radius < 0)
			throw new IllegalCircleException();
		this.radius = radius;
	}

	public double getArea() {
		return this.PI * Math.pow(radius, 2);
	}

	public double getPerimeter() {
		return this.PI * 2 * radius;
	}

	public String toString() {
		return "The Cricle : radius =" + printFormat.format(this.getRadius()) + " color = " + this.getColor()
				+ " isfilled =" + this.isFilled() + " area = " + getArea() + " perimeter = "
				+ printFormat.format(getPerimeter());
	}

	public void writeToFile(File f) throws IOException {
		FileOutputStream out=null;
		ObjectOutputStream output=null;
		try {
			out = new FileOutputStream(f, false);
			output = new ObjectOutputStream(out);
			output.writeObject(this);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			output.close();
			out.close();
		}
	}
}
