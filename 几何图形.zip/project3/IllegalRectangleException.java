package namespace2;

public class IllegalRectangleException extends Exception{
	IllegalRectangleException(){
		super("�쳣����");
	}
}
