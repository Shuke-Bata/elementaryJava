package namespace2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.DecimalFormat;
import java.util.Date;
import namespace1.IllegalCircleException;

public class Rectangle implements GeometricObject,java.io.Serializable {
	private String color = null;
	private boolean filled = false;
	private java.util.Date dateCreated;
	public final DecimalFormat printFormat = new DecimalFormat("0.00");
	private double width = 0, length = 0;

	public Rectangle() {

	}

	public Rectangle(double width, double length, String color, boolean filled)
			throws IllegalRectangleException {
		this.setColor(color);
		this.setFilled(filled);
		this.setLength(length);
		this.setWidth(width);
		dateCreated = new Date();
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isFilled() {
		return filled;
	}

	public void setFilled(boolean filled) {
		this.filled = filled;
	}

	public void draw(String color) {
		this.setColor(color);
	}

	public void erase() {
		this.setColor(null);
	}

	public double getArea() {
		return this.getLength() * this.getWidth();
	}

	public double getPerimeter() {
		return 2 * (this.getWidth() + this.getLength());
	}

	public double getWidth() {
		return  Double.parseDouble(printFormat.format(width));
	}

	public void setWidth(double width) throws IllegalRectangleException {
		if (width < 0)
			throw new IllegalRectangleException();
		this.width = width;
	}

	public double getLength() {
		return  Double.parseDouble(printFormat.format(length));
	}

	public void setLength(double length) throws IllegalRectangleException {
		if (length < 0)
			throw new IllegalRectangleException();
		this.length = length;
	}

	public String toString() {
		return "The Rectangle = length" + printFormat.format(this.getLength()) + "  width = "
				+ printFormat.format(this.getWidth()) + " color = " + this.getColor() + " isfilled =" + this.isFilled()
				+ " area = " + getArea() + " perimeter = " + printFormat.format(getPerimeter());
	}

	public void writeToFile(File f) throws IOException {
		FileOutputStream out = null;
		ObjectOutputStream output = null;
		try {
			out = new FileOutputStream(f, false);
			output = new ObjectOutputStream(out);
			output.writeObject(this);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			output.close();
			out.close();
		}
	}
}
