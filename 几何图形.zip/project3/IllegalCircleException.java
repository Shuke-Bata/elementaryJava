package namespace1;

public class IllegalCircleException extends Exception{
	public IllegalCircleException() {
		super("��ЧԲ��");
	}
}
