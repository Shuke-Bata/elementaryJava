package namespace2;
public interface GeometricObject {
	 void draw(String color);
	 void erase();
	 double getArea();
	 double getPerimeter();
}
